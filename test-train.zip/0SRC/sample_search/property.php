<?php require_once( 'couch/cms.php' ); ?>
   <cms:template title='Property' clonable='1' >
      <cms:editable name="my_intro" label="Introduction" type="textarea" />
                 
      <cms:editable name="my_addr" label="Address" height='70' type="textarea" />
                 
      <cms:editable name="my_locality" label="Locality" desc="Select one from these"
                    opt_values='Arera Colony  | M P Nagar | Old City | Karond'
                    opt_selected = 'Old City'
                    required='1'
                    type="dropdown" />
                    
      <cms:editable name="my_property_type" label="Property Type" desc="Select one from these"
                    opt_values='Residential  | Commercial | Rental'
                    required='1'
                    type="dropdown"/>
                    
      <cms:editable name="my_price" label="Price" desc='Amount in Rupee\'s (correct upto 2 decimal points)'
                    search_type='decimal'
                    validator='non_zero_decimal'
                    required='1'
                    type="text"/>		
                 
      <cms:editable name="my_num_bedrooms" label="Number Of Bedrooms" 
                    search_type='integer'
                    validator='non_negative_integer'
                    type="text">0</cms:editable>
                    
      <cms:editable name="my_num_bathrooms" label="Number Of Bathrooms" 
                    search_type='integer'
                    validator='non_negative_integer'
                    type="text">0</cms:editable>		
                    
      <cms:editable name="my_plot_area" label="Plot Area" desc="Plot area in sq.ft (correct upto 2 decimal points)"
                    search_type='decimal'
                    validator='non_zero_decimal'
                    required='1'
                    type="text"/>	
   </cms:template>


   <cms:if k_is_page >

      <!-- show single property detail here -->

   <cms:else />
   
      <!-- List view (shows search) -->
      <cms:embed 'search.htm' />

      Searching for:<cms:show my_search_str /><br /><!-- for debugging -->

      <cms:pages paginate='1' limit='10' custom_field="<cms:show my_search_str />" orderby='my_price' >
         <cms:if k_paginated_top >
            <cms:set my_records_found='1' scope='global'/>
            <cms:if k_paginator_required > 
               Page <cms:show k_current_page /> of <cms:show k_total_pages /><br />
            </cms:if>
            <cms:show k_total_records /> Properties Found. (Displaying: <cms:show k_record_from />-<cms:show k_record_to />)
         </cms:if>


         <h2><cms:show k_page_title /></h2>

         <cms:paginator simple='1' position='1' />
      </cms:pages>

      <cms:if my_records_found!='1' >
         No properties Found
      </cms:if>

   </cms:if>

<?php COUCH::invoke(); ?>