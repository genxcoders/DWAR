<?php
if ( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly

require_once( K_COUCH_DIR.'addons/cart/session.php' );
//require_once( K_COUCH_DIR.'addons/cart/cart.php' ); // automatically includes session
require_once( K_COUCH_DIR.'addons/data-bound-form/data-bound-form.php' );
require_once( K_COUCH_DIR.'addons/inline/inline.php' );
//require_once( K_COUCH_DIR.'addons/extended/extended-folders.php' );
//require_once( K_COUCH_DIR.'addons/extended/extended-comments.php' );
require_once( K_COUCH_DIR.'addons/extended/extended-users.php' );
require_once( K_COUCH_DIR.'addons/routes/routes.php' );
//require_once( K_COUCH_DIR.'addons/votes/votes.php' );
require_once( K_COUCH_DIR.'addons/csv/csv.php' );

/* ---------------------------------------------------- */

/* Allow authenticated-special users access to KCFinder 
http://www.couchcms.com/forum/viewtopic.php?f=4&t=9057&p=18689&hilit=bound+richtext#p18689

 ---------------------------------------------------- */
 
$FUNCS->register_tag( 'md5', array('CustomTags', 'md5_hasher') );
class CustomTags{
    function md5_hasher( $params, $node ){
        
        if( count($node->children) ) {die("ERROR: Tag \"".$node->name."\" is a self closing tag");}
      $res = $params[0]['rhs'];
        return md5( $res );
    }
} 

//
//usage: 
//<cms:php>time_elapsed('');</cms:php>
// ... block of code ...
//<cms:php>time_elapsed('DONE WITH THAT');</cms:php>
//
 function time_elapsed($comment) 
        {

        static $time_elapsed_last = null;
        static $time_elapsed_start = null;

         $unit="s"; $scale=1000000; // output in seconds
        // $unit="ms"; $scale=1000; // output in milliseconds
        // $unit="ms"; $scale=1000; // output in microseconds

        $now = microtime(true);

        if ($time_elapsed_last != null) {
            /*
			echo "\n";
            echo '<!-- ';
            echo "$comment: Time elapsed: ";
            echo round(($now - $time_elapsed_last)*1000000)/$scale;
            echo " $unit, total time: ";
            echo round(($now - $time_elapsed_start)*1000000)/$scale;
            echo " $unit -->";
            echo "\n";
			*/
			if( $comment ){
				$comment=$comment.': ';
            }
            echo "<p><b>$comment</b> Time elapsed: ";
            echo round(($now - $time_elapsed_last)*1000000)/$scale;
            echo " $unit </p>";
			
			
        } else {
            $time_elapsed_start=$now;
        }

        $time_elapsed_last = $now;
    }             
	
	