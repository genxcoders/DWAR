<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Pointwise Interchange Report" clonable='1' parent='_ptic_' order="2" >
	<cms:ignore>
	<cms:editable name="my_date" label="Date" type="datetime" fields_separator="-"  default_time='@current' order="1" />
	<cms:editable name="my_interchange" label="Interchange" type="dropdown" opt_values="Select =- | <cms:pages masterpage='interchange.php' order="asc" ><cms:show k_page_title /><cms:if '<cms:not k_paginated_bottom />' >|</cms:if></cms:pages>" order="2" />
	</cms:ignore>
</cms:template>
<cms:embed 'header.html' />
<cms:set to_live_count='0' scope='global' />
<cms:set to_death_count='0' scope='global' />
<cms:set to_locoacc_count='0' scope='global' />	
<cms:set to_traffic_count='0' scope='global' />

<cms:set ho_live_count='0' scope='global' />
<cms:set ho_death_count='0' scope='global' />
<cms:set ho_locoacc_count='0' scope='global' />	
<cms:set ho_traffic_count='0' scope='global' />
<!-- Content Here -->
	<div class="container-fluid">
		<div class="row">
			<div class="gxcpl-ptop-30"></div>
			<!-- Section Title -->
			<div class="col-md-12">
				<h4 class="gxcpl-no-margin">
					POINTWISE INTERCHANGE REPORT
					<div class="gxcpl-ptop-10"></div>
					<div class="gxcpl-divider-dark"></div>
					<div class="gxcpl-ptop-20"></div>
				</h4>
			</div>
			<!-- Section Title -->
			<cms:embed 'search.htm' />
			<cms:if interchange!="<cms:show my_search_str />">
			<cms:set size="<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'/> | to_ho=0" count_only='1' />" scope="global" />
			<div class="col-md-12">
				<div class="gxcpl-card">
					<div class="gxcpl-card-header">
						<div class="row">
							<div class="col-md-6">
								<h5 class="gxcpl-fw-700"><cms:pages masterpage="pointwise-interchange.php" limit='1' custom_field="interchange=<cms:gpc 'interchange' method='get' /> ">
								<cms:show interchange /></cms:pages>- TAKEN OVER TABLE</h5>
							</div>
							<div class="col-md-6">
								<div class="btn-group pull-right" role="group" style="margin-top: 2px;" >
									<a href="javascript:generatePDF()" class="btn btn-warning gxcpl-fw-700"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF</a>
									<!-- <a href="javascript:window.print();" class="btn btn-info gxcpl-fw-700"><i class="fa fa-print" aria-hidden="true"></i> PRINT</a>-->
									<!-- CSV Export -->
									<cms:set mystart="<cms:gpc 'import' method='get' />" />
    
								    <cms:if mystart >
								    
								        <cms:pages masterpage='pointwise-interchange.php'  paginate='1' limit='100' custom_field="interchange=<cms:show my_icp /> | arrival_date=<cms:date today_yesterday format='d/m/Y' /> | to_ho=<cms:show my_toho /> | is_interchanged=1" order='asc' orderby='arrival_time'>
								        
								            <cms:if k_paginated_top >
								                <cms:if k_current_page='1'>
								                    <!-- Header. 'truncate' starts a new file -->
								                    <cms:write 'my.csv' add_newline='1' truncate='1'>SrNo,TrainName,Loco,Schedule,Arrival,Remark</cms:write>
								                </cms:if>
								            
								                <cms:if k_paginate_link_next >
								                    <script language="JavaScript" type="text/javascript">
								                        var myVar;
								                        myVar = window.setTimeout( 'location.href="<cms:show k_paginate_link_next />";', 100 );
								                    </script>
								                    <button onclick="clearTimeout(myVar);">Stop</button>
								                <cms:else />
								                    <cms:set write_footer='1' />
								                    Done!    
								                </cms:if>
								                
								                <h3><cms:show k_current_page /> / <cms:show k_total_pages /> pages (Total <cms:show k_total_records /> records. Showing <cms:show k_paginate_limit /> records per page)</hr>
								            </cms:if>
								            
								                <h3><cms:show k_current_record /></h3>
								                
								                <!-- CSV row -->
								                <cms:write 'my.csv' add_newline='1'><cms:format_csv k_absolute_count />,<cms:format_csv tr_name />,<cms:format_csv loco/>,<cms:format_csv schedule /><cms:date schedule_date format='d-m'/>,<cms:date arrival_time format='H:i' />,<cms:format_csv remark/></cms:write>

								            <cms:if k_paginated_bottom >
								                <hr>
								                
								                <!-- Footer -->
								                <cms:if write_footer>
								                    <!-- CSV does not require a footer so doing nothing here but for XML this could be used to output the document closing tags -->
								                <cms:else />
								                    <cms:paginator simple='1' />
								                </cms:if>    
								            </cms:if>
								            
								        </cms:pages>    
								    <cms:else/>
								    <cms:ignore>
								        <!-- <button class="btn btn-success gxcpl-fw-700" onclick="location.href='<cms:add_querystring k_page_link "arrival_date=<cms:date today_yesterday format='Y-m-d'/>&interchange=<cms:gpc 'interchange' method='get' />&submit=ENTER&k_hid_quicksearch=quicksearch&nc=1&import=1" />' "><i class="fa fa-file-excel-o" aria-hidden="true" ></i> EXCEL</button> -->
								    </cms:ignore>
								    </cms:if>
									<!-- CSV Export -->
									<button id="btnShow" class="btn btn-danger gxcpl-fw-700" type="button" class="btn btn-default">
										<i class="fa fa-eye" aria-hidden="true"></i> SHOW
									</button>
									<button id="btnHide" class="btn btn-primary gxcpl-fw-700" type="button" class="btn btn-default">
										<i class="fa fa-eye-slash" aria-hidden="true"></i> HIDE
									</button>
								</div>
							</div>
						</div>
					</div>
					<div class="gxcpl-card-body tableFixHead <cms:if size>scroll</cms:if>">
						<table class="gxcpl-table" id="to">
							<thead>
							    <tr>
									<th class="text-center">
										S.No.
									</th>
									<th>
										Train
									</th>
									<th>
										Loco
									</th>
									<th>
										Schedule
									</th>
									<th>
										Location
									</th>
									<th>
										Arr/Dep
									</th>
									<th>
										Sign-on
									</th>
									<th>
										Remarks
									</th>
									<th style="display: none;">
										From
									</th>
									<th style="display: none;">
										To
									</th>
									<th style="display: none;">
										CMDT
									</th>
									<th style="display: none;">
										Type
									</th>
									<th style="display: none;">
										L/E
									</th>
									<th style="display: none;">
										Units
									</th>
								</tr>
							</thead>
							<tbody>
								<!-- For Interchanged -->
								<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get' /> | to_ho=0 | is_interchanged='1' | departure_time<>'1970-01-01 00:00:00'" order='asc' orderby="arrival_date">
								<cms:ignore>Setting Sign On time to calculate if the row is changing color</cms:ignore>
								<cms:set arrival = "<cms:date arrival_time format='H:i' />" scope='global' />
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table.html' />
							 	</cms:pages>
							 	<!-- For Interchanged -->

							 	<!-- For Interchanged && Not Dep Time Set -->
							 	<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get' /> | to_ho=0 | is_interchanged='1' | departure_time='1970-01-01 00:00:00'" order='asc' orderby="arrival_date">
								<cms:ignore>Setting Sign On time to calculate if the row is changing color</cms:ignore>
								<cms:set arrival = "<cms:date arrival_time format='H:i' />" scope='global' />
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table.html' />
							 	</cms:pages>
							 	<!-- For Interchanged && Not Dep Time Set -->

							 	<!-- For NOT Interchanged -->
							 	<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get' /> | to_ho=0 | is_interchanged<>'1' | departure_time<>'1970-01-01 00:00:00'" order='asc' orderby="arrival_date">
								<cms:ignore>Setting Sign On time to calculate if the row is changing color</cms:ignore>
								<cms:set arrival = "<cms:date arrival_time format='H:i' />" scope='global' />
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table.html' />
							 	</cms:pages>
							 	<!-- For NOT Interchanged -->

							 	<!-- For NOT Interchanged && Not Dep Time Set -->
							 	<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get' /> | to_ho=0 | is_interchanged<>'1' | departure_time='1970-01-01 00:00:00'" order='asc' orderby="arrival_date">
								<cms:ignore>Setting Sign On time to calculate if the row is changing color</cms:ignore>
								<cms:set arrival = "<cms:date arrival_time format='H:i' />" scope='global' />
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table.html' />
							 	</cms:pages>
							 	<!-- For NOT Interchanged && Not Dep Time Set -->
							</tbody>
						</table>
					</div>
					<div class="gxcpl-card-footer" style="line-height: 24px; text-align: left;">
						<cms:set abs_count="<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=0 " order='asc' orderby='arrival_time' count_only='1' />" scope='global' />
						<strong>Forecasted: </strong><cms:show abs_count />
						<br>
						<strong>Taken Over(TO): </strong><cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=0 | is_interchanged=1" order='asc' orderby='arrival_time' count_only='1' />
						<br>
						<cms:set to_abs_count_pdf="<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=0 | is_interchanged=1" order='asc' orderby='arrival_time' count_only='1' />" scope='global' />
						<cms:set to_live_count_pdf="<cms:show to_live_count />" scope='global' />
						<cms:set to_death_count_pdf="<cms:show to_death_count />" scope='global' />
						<cms:set to_total_count_pdf="<cms:add to_live_count to_death_count />" scope='global' />

					</div>
				</div>
				<div class="gxcpl-ptop-30"></div>
			</div>
			<div class="col-md-12">
				<div class="gxcpl-card">
					<div class="gxcpl-card-header">
						<h5 class="gxcpl-fw-700"><cms:pages masterpage="pointwise-interchange.php" limit="1" custom_field="interchange=<cms:gpc 'interchange' />"><cms:show interchange /></cms:pages>- HANDED OVER TABLE</h5>
					</div>
					<div class="gxcpl-card-body tableFixHead <cms:if size>scroll</cms:if>">
						<table class="gxcpl-table" id="ho">
							<thead>
							    <tr>
									<th class="text-center">
										S.No.
									</th>
									<th>
										Train
									</th>
									<th>
										Loco
									</th>
									<th>
										Schedule
									</th>
									<th>
										Location
									</th>
									<th>
										Arr / Dep
									</th>
									<th>
										Sign-on
									</th>
									<th>
										Remarks
									</th>
									<th style="display: none;">
										From
									</th>
									<th style="display: none;">
										To
									</th>
									<th style="display: none;">
										CMDT
									</th>
									<th style="display: none;">
										Type
									</th>
									<th style="display: none;">
										L/E
									</th>
									<th style="display: none;">
										Units
									</th>
								</tr>
							</thead>
							<tbody>

								<!-- For Interchanged -->
								<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get' /> | to_ho=1 | is_interchanged='1' | departure_time<>'1970-01-01 00:00:00'" order='asc' orderby="departure_time">							

								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table-ho.html' />

								<cms:ignore>
								<cms:embed 'overdue.html' />
							 	<cms:if (is_interchanged eq '1') >
								<cms:embed 'ptwise-int-report-table-ho.html' />
								<cms:else_if (is_interchanged eq '1') />
								<cms:embed 'ptwise-int-report-table-ho.html' />
								<cms:else />
								<cms:embed 'ptwise-int-report-table-ho.html' />
								</cms:if>
								</cms:ignore>

								</cms:pages>
								<!-- For Interchanged -->

								<!-- For Interchanged && Not Dep Time Set -->
								<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1  | is_interchanged='1' | departure_time='1970-01-01 00:00:00'" order='asc' orderby="departure_time">
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table-ho.html' />
								</cms:pages>
								<!-- For Interchanged && Not Dep Time Set -->

								<!-- For NOT Interchanged -->
								<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1  | is_interchanged<>'1' | departure_time<>'1970-01-01 00:00:00'" order='asc' orderby="departure_time">
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table-ho.html' />
								</cms:pages>
								<!-- For NOT Interchanged -->

								<!-- For NOT Interchanged && Not Dep Time Set -->
								<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | to_ho=1 | is_interchanged<>'1' | departure_time='1970-01-01 00:00:00'" order='asc' orderby="departure_time">
								<cms:set my_counter="1" scope="global" />
								<cms:set dep_time="<cms:date departure_time format='H:i' />" scope="global" />
								<cms:embed 'overdue.html' />
								<cms:embed 'ptwise-int-report-table-ho.html' />
								</cms:pages>
								<!-- For NOT Interchanged && Not Dep Time Set -->
							</tbody>
						</table>
					</div>
					<div class="gxcpl-card-footer" style="line-height: 24px; text-align: left;">
						<cms:set ho_abs_count="<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1" order='asc' orderby='departure_time' count_only='1' />" scope='global' />
						<strong>Forecasted: </strong><cms:show ho_abs_count />
						
						<br>
						<strong>Handed Over(HO): </strong><cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1 | is_interchanged=1" order='asc' orderby='departure_time' count_only='1' />
						
						<cms:set ho_abs_count_pdf="<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1 | is_interchanged=1" order='asc' orderby='departure_time' count_only='1' />" scope='global' />
						<cms:set ho_live_count_pdf="<cms:show ho_live_count />" scope='global' />
						<cms:set ho_death_count_pdf="<cms:show ho_death_count />" scope='global' />
						<cms:set ho_total_count_pdf="<cms:add ho_live_count ho_death_count />" scope='global' />
						
					</div>
				</div>
				<div class="gxcpl-ptop-50"></div>
			</div>
			<cms:else />
			
			</cms:if> 
			
		</div>
	</div>
	<!-- Content Here -->
<cms:pages masterpage='pointwise-interchange.php' limit="1" >
<cms:set arri = "<cms:gpc 'arrival_date' method='get' />" scope='global'  />
	<script>
		function generatePDF() {
		var dd = {
			pageSize:'A4',
			pageOrientation:'potrait',
			content: 
			[	
				{ text: 'Interchange Point <cms:pages masterpage="pointwise-interchange.php" limit='1' custom_field="interchange=<cms:gpc 'interchange' method='get' /> "><cms:show interchange /></cms:pages>', style: 'subheader', alignment: 'center' },
					'\n',
				{ text: 'Date:- <cms:date arri format= "d/m/Y" />', style: 'subheader', alignment: 'center' },
					'\n',
				{
					style: 'tableExample', alignment: 'center', fontSize: 8.3, border:0, margin: [20, 2], 
					table: {
						body: 
						[
							[
								{ 
									text:'Forecasted: <cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=0 " order='asc' orderby='arrival_time' count_only='1' />\nTaken Over(HO): <cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=0 | is_interchanged=1" order='asc' orderby='arrival_time' count_only='1' />', style: 'subheader', alignment: 'center', margin:5
								},
								{ 
									text:'Forecasted: <cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1 " order='asc' orderby='departure_time' count_only='1' />\nHanded Over(HO): <cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1 | is_interchanged=1" order='asc' orderby='departure_time' count_only='1' />', style: 'subheader', alignment: 'center', margin:5
								},
							],
							[
								[{text: '<cms:pages masterpage="pointwise-interchange.php" limit='1' custom_field="interchange=<cms:gpc 'interchange' method='get' /> "><cms:show interchange /></cms:pages>- TAKEN OVER TABLE', style: 'subheader', bold: true,fontSize: 10,
								}],

								[{text: '<cms:pages masterpage="pointwise-interchange.php" limit='1' custom_field="interchange=<cms:gpc 'interchange' method='get' /> "><cms:show interchange /></cms:pages>- HANDED OVER TABLE', style: 'subheader', bold: true,fontSize: 10,
								}]
							],
							[
								{
									style: 'tableExample', alignment: 'center',  
									table: {
										headerRows: 1,
										body: [
											[{text: 'S.No.', style: 'tableHeader', bold: true, fontSize: 9,}, 
											 {text: 'Train', style: 'tableHeader', bold: true, fontSize: 9,}, 
											 {text: 'Loco', style: 'tableHeader', bold: true, fontSize: 9,},
											 {text: 'Schedule', style: 'tableHeader', bold: true, fontSize: 9,}, 
											 {text: 'Arrival', style: 'tableHeader', bold: true, fontSize: 9,}, 
											 ],

											<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=0  | is_interchanged=1" order='asc' orderby='arrival_time'>
											<cms:set tr_name_caps="<cms:php>echo strtoupper('<cms:show tr_name />');</cms:php>" />
											<cms:set schedule_caps="<cms:php>echo strtoupper('<cms:show schedule />');</cms:php>" />
											 	
											['<cms:show k_absolute_count />', '<cms:show tr_name_caps />', '<cms:show loco />', 
											 '<cms:show schedule_caps /><cms:date schedule_date format='d-m' />', '<cms:date arrival_time format='H:i' />', ],
											 </cms:pages>
											 ['', '', '', '', '', ],
											 ['', '', '', '', '', ],
											 ['', 'Total', '<cms:show to_abs_count_pdf />=<cms:show to_live_count_pdf />+<cms:show to_death_count_pdf />D', '', '', ], 
											 ['', '', '<cms:show to_total_count_pdf />AC', '', '', ],
										]
									},
								},
								[
									{
									style: 'tableExample', 
									table: {
										headerRows: 1,
										body: [
											[{text: 'S.No.', style: 'tableHeader', bold: true, fontSize: 9, }, 
											 {text: 'Train', style: 'tableHeader', bold: true, fontSize: 9,}, 
											 {text: 'Loco', style: 'tableHeader', bold: true, fontSize: 9,},
											 {text: 'Schedule', style: 'tableHeader', bold: true, fontSize: 9,}, 
											 {text: 'Departure', style: 'tableHeader', bold: true, fontSize: 9,}, ],

											 <cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1  | is_interchanged=1" order='asc' orderby='departure_time'>
											<cms:set tr_name_caps="<cms:php>echo strtoupper('<cms:show tr_name />');</cms:php>" />
											<cms:set schedule_caps="<cms:php>echo strtoupper('<cms:show schedule />');</cms:php>" />

											['<cms:show k_absolute_count />', '<cms:show tr_name_caps />', '<cms:show loco />', 
											 '<cms:show schedule_caps /><cms:date schedule_date format='d-m' />', '<cms:date departure_time format='H:i' />', ],
											 </cms:pages>
											 ['', '', '', '', '', ],
											 ['', '', '', '', '',  ],
											 ['', 'Total', '<cms:show ho_abs_count_pdf />=<cms:show ho_live_count_pdf />+<cms:show ho_death_count_pdf />D', '', '', ], 
											 ['', '', '<cms:show ho_total_count_pdf />AC', '', '', ],
										]
									},
								},
								],
							]
						]
					},
					layout: 'noBorders'
				},
			],
			
		}
		pdfMake.createPdf(dd).open();
		}
	</script>
</cms:pages>
	<cms:embed "footer.html" />
<?php COUCH::invoke( ); ?>