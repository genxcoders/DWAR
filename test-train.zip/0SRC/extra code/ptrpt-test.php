<?php require_once( 'couch/cms.php' ); ?>
<cms:template title='Report: Pointwise Interchange' parent='_ptic_' order="3" />
<cms:embed "header.html" />
<div class="gxcpl-ptop-50"></div>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<cms:embed 'search.htm' />
			<div class="gxcpl-ptop-30"></div>
		</div>
		<div class="col-md-12">
			<h3>H/O Table</h3>
			<div class="gxcpl-ptop-30"></div>
		</div>
		<div class="col-md-12">
			<table class="gxcpl-table">
				<thead>
					<tr>
						<th class="text-center">
							S.No.
						</th>
						<th>
							Train
						</th>
						<th>
							Loco
						</th>
						<th>
							Schedule
						</th>
						<th>
							Location
						</th>
						<th>
							Arr/Dep
						</th>
						<th>
							Sign-on
						</th>
						<th>
							Remarks
						</th>
						<th style="display: none;">
							From
						</th>
						<th style="display: none;">
							To
						</th>
						<th style="display: none;">
							CMDT
						</th>
						<th style="display: none;">
							Type
						</th>
						<th style="display: none;">
							L/E
						</th>
						<th style="display: none;">
							Units
						</th>
					</tr>
				</thead>
				<tbody>
					<tr><td>Interchanged</td></tr>
					<cms:ignore>
					<cms:pages masterpage='pointwise-interchange.php' custom_field="interchange=<cms:gpc 'interchange' method='get' /> | arrival_date=<cms:gpc 'arrival_date' method='get' /> | <cms:gpc 'to_ho' method='get'  /> | to_ho=1 | is_interchanged=1" order='asc' orderby="departure_time">
					<cms:set dep_time="<cms:date departure_time format='H:i' />" scope="global" />
						<cms:no_results>
						<tr>
							<td class="text-center" colspan='14'>
								- No Data -
							</td>
						</tr>
						</cms:no_results>
						<tr style='border-bottom: 1px solid rgba(0,0,0,0.2);'>
							<td class="text-center <cms:if is_interchanged eq '1' >srintchge</cms:if> ">
								<cms:show k_absolute_count />
							</td>
							<td class="text-uppercase <cms:if is_stabled eq '1' >stable</cms:if> ">
								<cms:if tr_name>
									<cms:show tr_name /> :: (<cms:show is_interchanged />)
									<cms:else />
									- NA -
								</cms:if>
							</td>
							<td class="text-uppercase">
								<cms:if loco >
									<cms:each loco sep='+' >
										<cms:php>
											$string = '<cms:show item />';
											global $new_string;
											$new_string = preg_replace("/[^A-Za-z?!\s]/","", $string);
										</cms:php>
										<cms:set char_alpha="<cms:php>global $new_string; echo $new_string;</cms:php>" scope='global' />
										
										<cms:if k_count eq '0'>
											<cms:if char_alpha eq 'D'>
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_death_count '1' />
												</cms:if>
												<cms:show item />
											<cms:else />
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_live_count '1' />
												</cms:if>
												<br><cms:show item />
											</cms:if>
										<cms:else_if k_count eq '1'/>
											<cms:if char_alpha eq 'D'>
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_death_count '1' />
												</cms:if>
												<cms:show item />
											<cms:else />
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_live_count '1' />
												</cms:if>
												<br><cms:show item />
											</cms:if>
										</cms:if>
									</cms:each>
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td class="text-uppercase <cms:if sch_overdue eq '1'>sch_overdue</cms:if> ">
								<cms:if schedule && schedule_date >
									<cms:show schedule /> <cms:date schedule_date format='d-m' />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td>
								<cms:set related_location="<cms:related_pages 'location'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_location>
									<cms:show related_location />
								<cms:else />
									- NA -
								</cms:if>
							</td>
							<td>
								<cms:if arrival_time ><cms:date arrival_time format='H:i' /><cms:else />-NA-</cms:if> / <cms:if departure_time ><cms:date departure_time format='H:i' /><cms:else />-NA-</cms:if>
							</td>
							<td <cms:if (is_interchanged ne '1') && ( overdue eq '1') >
								class="overdue"
								</cms:if>
							>
								<cms:if signon_date >
									<cms:date signon_date format='H:i' />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td>
								<div <cms:inline_edit 'remark' toolbar='custom' /> >
									<cms:if remark >
										<cms:show remark />
									<cms:else />
										-NA-
									</cms:if>
								</div>
							</td>
							<td style="display: none;">
								<cms:if stn_from >
									<cms:show stn_from />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;"> 
								<cms:if stn_to >
									<cms:show stn_to />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:set related_commodity="<cms:related_pages 'commodity'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_commodity>
									<cms:show related_commodity />
								<cms:else />
									- NA -
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:set related_raketype="<cms:related_pages 'raketype'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_raketype>
									<cms:show related_raketype />
								<cms:else />
									- NA -
								</cms:if> 
							</td>
							<td style="display: none;">
								<cms:if load >
									<cms:show load />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:if load_unit >
									<cms:show load_unit />
								<cms:else />
									-NA-
								</cms:if>
							</td>
						</tr>
					</cms:pages>
					</cms:ignore>
					<tr><td>Not Interchanged</td></tr>
					<cms:pages masterpage='pointwise-interchange.php' custom_field="to_ho=1" order='asc' orderby="departure_time">
					<cms:set dep_time="<cms:date departure_time format='H:i' />" scope="global" />
						<cms:no_results>
						<tr>
							<td class="text-center" colspan='14'>
								- No Data -
							</td>
						</tr>
						</cms:no_results>
						<cms:if is_interchanged eq '1'>
						<tr style='border-bottom: 1px solid rgba(0,0,0,0.2);'>
							<td class="text-center <cms:if is_interchanged eq '1' >srintchge</cms:if> ">
								<cms:show k_absolute_count />
							</td>
							<td class="text-uppercase <cms:if is_stabled eq '1' >stable</cms:if> ">
								<cms:if tr_name>
									<cms:show tr_name /> :: (<cms:show is_interchanged />)
									<cms:else />
									- NA -
								</cms:if>
							</td>
							<td class="text-uppercase">
								<cms:if loco >
									<cms:each loco sep='+' >
										<cms:php>
											$string = '<cms:show item />';
											global $new_string;
											$new_string = preg_replace("/[^A-Za-z?!\s]/","", $string);
										</cms:php>
										<cms:set char_alpha="<cms:php>global $new_string; echo $new_string;</cms:php>" scope='global' />
										
										<cms:if k_count eq '0'>
											<cms:if char_alpha eq 'D'>
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_death_count '1' />
												</cms:if>
												<cms:show item />
											<cms:else />
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_live_count '1' />
												</cms:if>
												<br><cms:show item />
											</cms:if>
										<cms:else_if k_count eq '1'/>
											<cms:if char_alpha eq 'D'>
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_death_count '1' />
												</cms:if>
												<cms:show item />
											<cms:else />
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_live_count '1' />
												</cms:if>
												<br><cms:show item />
											</cms:if>
										</cms:if>
									</cms:each>
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td class="text-uppercase <cms:if sch_overdue eq '1'>sch_overdue</cms:if> ">
								<cms:if schedule && schedule_date >
									<cms:show schedule /> <cms:date schedule_date format='d-m' />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td>
								<cms:set related_location="<cms:related_pages 'location'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_location>
									<cms:show related_location />
								<cms:else />
									- NA -
								</cms:if>
							</td>
							<td>
								<cms:if arrival_time ><cms:date arrival_time format='H:i' /><cms:else />-NA-</cms:if> / <cms:if departure_time ><cms:date departure_time format='H:i' /><cms:else />-NA-</cms:if>
							</td>
							<td <cms:if (is_interchanged ne '1') && ( overdue eq '1') >
								class="overdue"
								</cms:if>
							>
								<cms:if signon_date >
									<cms:date signon_date format='H:i' />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td>
								<div <cms:inline_edit 'remark' toolbar='custom' /> >
									<cms:if remark >
										<cms:show remark />
									<cms:else />
										-NA-
									</cms:if>
								</div>
							</td>
							<td style="display: none;">
								<cms:if stn_from >
									<cms:show stn_from />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;"> 
								<cms:if stn_to >
									<cms:show stn_to />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:set related_commodity="<cms:related_pages 'commodity'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_commodity>
									<cms:show related_commodity />
								<cms:else />
									- NA -
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:set related_raketype="<cms:related_pages 'raketype'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_raketype>
									<cms:show related_raketype />
								<cms:else />
									- NA -
								</cms:if> 
							</td>
							<td style="display: none;">
								<cms:if load >
									<cms:show load />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:if load_unit >
									<cms:show load_unit />
								<cms:else />
									-NA-
								</cms:if>
							</td>
						</tr>
						</cms:if>
					</cms:pages>
					<cms:pages masterpage='pointwise-interchange.php' custom_field="to_ho=1" order='asc' orderby="departure_time">
					<cms:set dep_time="<cms:date departure_time format='H:i' />" scope="global" />
						<cms:no_results>
						<tr>
							<td class="text-center" colspan='14'>
								- No Data -
							</td>
						</tr>
						</cms:no_results>
						<cms:if is_interchanged eq ''>
						<tr style='border-bottom: 1px solid rgba(0,0,0,0.2);'>
							<td class="text-center <cms:if is_interchanged eq '1' >srintchge</cms:if> ">
								<cms:show k_absolute_count />
							</td>
							<td class="text-uppercase <cms:if is_stabled eq '1' >stable</cms:if> ">
								<cms:if tr_name>
									<cms:show tr_name /> :: (<cms:show is_interchanged />)
									<cms:else />
									- NA -
								</cms:if>
							</td>
							<td class="text-uppercase">
								<cms:if loco >
									<cms:each loco sep='+' >
										<cms:php>
											$string = '<cms:show item />';
											global $new_string;
											$new_string = preg_replace("/[^A-Za-z?!\s]/","", $string);
										</cms:php>
										<cms:set char_alpha="<cms:php>global $new_string; echo $new_string;</cms:php>" scope='global' />
										
										<cms:if k_count eq '0'>
											<cms:if char_alpha eq 'D'>
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_death_count '1' />
												</cms:if>
												<cms:show item />
											<cms:else />
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_live_count '1' />
												</cms:if>
												<br><cms:show item />
											</cms:if>
										<cms:else_if k_count eq '1'/>
											<cms:if char_alpha eq 'D'>
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_death_count '1' />
												</cms:if>
												<cms:show item />
											<cms:else />
												<cms:if is_interchanged eq '1'>
													<cms:incr ho_live_count '1' />
												</cms:if>
												<br><cms:show item />
											</cms:if>
										</cms:if>
									</cms:each>
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td class="text-uppercase <cms:if sch_overdue eq '1'>sch_overdue</cms:if> ">
								<cms:if schedule && schedule_date >
									<cms:show schedule /> <cms:date schedule_date format='d-m' />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td>
								<cms:set related_location="<cms:related_pages 'location'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_location>
									<cms:show related_location />
								<cms:else />
									- NA -
								</cms:if>
							</td>
							<td>
								<cms:if arrival_time ><cms:date arrival_time format='H:i' /><cms:else />-NA-</cms:if> / <cms:if departure_time ><cms:date departure_time format='H:i' /><cms:else />-NA-</cms:if>
							</td>
							<td <cms:if (is_interchanged ne '1') && ( overdue eq '1') >
								class="overdue"
								</cms:if>
							>
								<cms:if signon_date >
									<cms:date signon_date format='H:i' />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td>
								<div <cms:inline_edit 'remark' toolbar='custom' /> >
									<cms:if remark >
										<cms:show remark />
									<cms:else />
										-NA-
									</cms:if>
								</div>
							</td>
							<td style="display: none;">
								<cms:if stn_from >
									<cms:show stn_from />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;"> 
								<cms:if stn_to >
									<cms:show stn_to />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:set related_commodity="<cms:related_pages 'commodity'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_commodity>
									<cms:show related_commodity />
								<cms:else />
									- NA -
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:set related_raketype="<cms:related_pages 'raketype'><cms:show k_page_title /></cms:related_pages>" />
								<cms:if related_raketype>
									<cms:show related_raketype />
								<cms:else />
									- NA -
								</cms:if> 
							</td>
							<td style="display: none;">
								<cms:if load >
									<cms:show load />
								<cms:else />
									-NA-
								</cms:if>
							</td>
							<td style="display: none;">
								<cms:if load_unit >
									<cms:show load_unit />
								<cms:else />
									-NA-
								</cms:if>
							</td>
						</tr>
						</cms:if>
					</cms:pages>
				</tbody>
			</table>
		</div>
	</div>
</div>
<cms:embed "footer.html" />
<?php COUCH::invoke( ); ?>