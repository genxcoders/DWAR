<?php require_once( 'couch/cms.php' ); ?>
<cms:embed "header.html" />
<a href="javascript:stablePDF()" class="btn btn-warning gxcpl-fw-700"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF</a>
<cms:pages masterpage="pointwise-interchange.php" custom_field="is_stabled='1' | is_interchanged=1" order='desc' orderby='arrival_date' >
	<script type="text/javascript">
		function stablePDF(){
			var dd = {
				pageSize:'A4',
				pageOrientation:'potrait',
				content: 
				[
					{text: 'Stable Trains', style: 'subheader' , alignment: 'center'},
					'\n',
					{
						style: 'tableExample', alignment: 'center', fontSize: 8.3, border:0, margin: [50, 2],   
						table: {
							headerRows: 1,
							// dontBreakRows: true,
							// keepWithHeaderRows: 1,
							body: [
								[{text: 'Sr. No.', style: 'tableHeader', bold: true, fontSize: 9,}, 
								 {text: 'Train', style: 'tableHeader', bold: true, fontSize: 9,},
								 {text: 'Loco', style: 'tableHeader', bold: true, fontSize: 9,}, 
								 {text: 'Arrival Date', style: 'tableHeader', bold: true, fontSize: 9,},
								 {text: 'Arrival Time', style: 'tableHeader', bold: true, fontSize: 9,}, 
								 {text: 'Location', style: 'tableHeader', bold: true, fontSize: 9,},
								 {text: 'Remark', style: 'tableHeader', bold: true, fontSize: 9,}
								 ],
								
								<cms:pages masterpage="pointwise-interchange.php" custom_field="is_stabled='1' | is_interchanged=1" order='desc' orderby='arrival_date' >
								
								[
									'<cms:show k_absolute_count />',
									'<cms:show tr_name />',
									'<cms:show loco />',
									'<cms:date arrival_date format='d-m-Y' />',
									'<cms:date arrival_time format="H:i" />',
									'<cms:related_pages 'location'><cms:show k_page_title /></cms:related_pages>',
									'<cms:if remark ><cms:show remark /><cms:else />-NA-</cms:if>',
								],
								</cms:pages>
								
							]
						}
					},
				]
			}
			pdfMake.createPdf(dd).open();
		}
	</script>
</cms:pages>
<cms:embed "footer.html" />
<?php COUCH::invoke( ); ?>
	