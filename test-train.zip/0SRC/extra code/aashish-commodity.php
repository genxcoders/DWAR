<?php require_once( 'couch/cms.php' ); ?>
	<cms:template title='OHE Value: Lat &amp; Long' order='1' />
	<cms:set ohe_val="<cms:gpc 'keyname' method='get' />" scope='global' />
	<cms:content_type 'application/json'/>
	<cms:pages masterpage='ohe-mast.php' custom_field="ipt_ohe_mast=<cms:show ohe_val />" limit='1'>
	
	<cms:abort>
	{
		"receive":
		[
			{
				"latitude": <cms:escape_json><cms:show ipt_lati /></cms:escape_json>,
				"longitude": <cms:escape_json><cms:show ipt_long /></cms:escape_json>
			}
		]
	}
	</cms:abort>
	
	</cms:pages>
<?php COUCH::invoke( K_IGNORE_CONTEXT ); ?>

<?php require_once( 'couch/cms.php' ); ?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>

		<select name="commodity" id="commodity">
			<option id="-" selected disabled>Select Commodity</option>
			<cms:pages masterpage='ncoal-commodity.php'>
			<option value="<cms:show k_page_id />"><cms:show k_page_title /></option>
			</cms:pages>
		</select>

		<script type="text/javascript" src="<cms:show k_site_link />assets/js/jquery-1.11.1.js"></script>
		<script type="text/javascript">
			$('#commodity').change(function(){
				$.ajax({
					type: 'get',
					url: "<cms:show k_site_link />ohe-ajax.php",
					dataType:"json",
					contentType:"application/json; charset=utf-8",
					data:  {keyname:$('#f_ipt_ohemast option:selected').val()},
					success: function(data){
			            var items = "";
        				for (var i = 0; i < data.receive.length; i++) {
        					items += $('#t1').val(data.receive[i].latitude);
			            	items += $('#t2').val(data.receive[i].longitude);
        				}
					}
				});
			});
		</script>
	</body>
</html>
<?php COUCH::invoke(); ?>