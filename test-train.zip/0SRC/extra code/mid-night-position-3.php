<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Midnight Position-3" clonable="1" routable='1' parent='_mdpt_' order='3'>
	<!-- DATE on Every page -->
    <cms:editable name="mdp_date" label="Mid-Night Position Date" type="datetime" allow_time='0' required="1" format="Y-m-d" order="1" />
   	<!-- DATE on Every page -->

   	<!-- PUNCTUALITY  -->
   	<cms:editable name="punc_row" label="Puncualtilty" type="row" order="2">
   		<cms:editable name="mexp_punc1" label="M/Exp Punctuality" type="text" order="2" class="col-md-3" />
   		<cms:editable name="mexp_run_punc1" label="M/Exp Run" type="text" order="3" class="col-md-3" />
   		<cms:editable name="mexp_lost_punc1" label="M/Exp Lost" type="text" order="4" class="col-md-3" />
   		<cms:editable name="mexp_trno_punc1" label="M/Exp Train Number" type="text" order="5" class="col-md-3" />
   		<cms:editable name="pass_punc1" label="Pass Punctuality" type="text" order="6" class="col-md-3" />
   		<cms:editable name="pass_run_punc1" label="Pass Run" type="text" order="7" class="col-md-3" />
   		<cms:editable name="pass_lost_punc1" label="Pass Lost" type="text" order="8" class="col-md-3" />
   		<cms:editable name="pass_trno_punc1" label="Pass Train Number" type="text" order="9" class="col-md-3" />
   	</cms:editable>
   	<!-- PUNCTUALITY  -->
	<!-- Custom Routes -->
	<cms:route name='list_mnp3' path='' />
	<cms:route name='create_mnp3' path='create' />
	<cms:route name='edit_mnp3' path='{:id}/edit' >
	    <cms:route_validators id='non_zero_integer' />
	</cms:route>
	<cms:route name='delete_mnp3' path='{:id}/delete' >
	    <cms:route_validators id='non_zero_integer' />
	</cms:route>
	<!-- Custom Routes -->
</cms:template>
<cms:embed 'header.html' />               
	<!-- Content Here -->
	<div class="container-fluid">
	    <div class="row">
			<div class="gxcpl-ptop-30"></div>

			<!-- Section Divider -->
			<div class="gxcpl-ptop-10"></div>
			<!-- <div class="gxcpl-divider-dark"></div> -->
			<div class="gxcpl-ptop-10"></div>
			<!-- Section Divider -->

			<!-- Mid Night Position -->
			<cms:match_route debug='0' />
			<cms:embed "mid-posi-3/<cms:show k_matched_route />.html" />
			<!-- Mid Night Position -->
	    </div>
	</div>
	<!-- Content Here -->		
<cms:embed 'footer.html' />               
<?php COUCH::invoke( K_IGNORE_CONTEXT ); ?>