<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Multi Step Form" clonable='1' routable='1' parent='_mdpt_' order='6' >
</cms:template>
<!-- Regular form. Just make sure the method is 'post' -->
   <cms:form anchor='0' method='post'>

   <cms:set total_pages = '3' />

   <cms:embed 'multi_form_handler.html' />
   
   <cms:if k_current_step gt total_pages >
      <h2>Thank you for contacting us</h2>
      <h4>Current Values:</h4>
      <p>
         Element 1: <cms:show frm_element_1 /><br>
         Element 2: <cms:show frm_element_2 /><br>
         Element 3: <cms:show frm_element_3 /><br>
         Element 4: <cms:show frm_element_4 /><br>
         Element 5: <cms:show frm_element_5 />  
      </p>     
   <cms:else />     
   
      <cms:if k_current_step='1' >
         <fieldset>
            <legend>Page One (1 of 3)</legend>
            <p>
               <label for='element_1'>Element 1:</label><cms:input type='text' name='element_1' required='1' /> (required)
               <cms:if k_error_element_1 ><span style="color:red"><cms:show k_error_element_1 /></span></cms:if>
            </p>
            <p><label for='element_2'>Element 2:</label><cms:input type='text' name='element_2' /></p>
         </fieldset>
      </cms:if>

      <cms:if k_current_step='2' >
         <fieldset>
            <legend>Page Two (2 of 3)</legend>
            <p><label for='element_3'>Element 3:</label><cms:input type='text' name='element_3' /></p>
            <p>
               <label for='element_4'>Element 4:</label><cms:input type='text' name='element_4' required='1' /> (required)
               <cms:if k_error_element_4 ><span style="color:red"><cms:show k_error_element_4 /></span></cms:if>
            </p>
         </fieldset>
      </cms:if>   
      
      <cms:if k_current_step='3' >
         <fieldset>
            <legend>Page Three (3 of 3)</legend>
            <p><label for='element_5'>Element 5:</label><cms:input type='text' name='element_5' /></p>
            <p><label for='element_6'>Element 6:</label><cms:input type='text' name='element_6'/></p>
         </fieldset>
      </cms:if> 

      <cms:if k_current_step='4' >
         <fieldset>
            <legend>Page Three (3 of 3)</legend>
            <p><label for='element_5'>Element 5:</label><cms:input type='text' name='element_5' /></p>
            <p><label for='element_6'>Element 6:</label><cms:input type='text' name='element_6'/></p>
         </fieldset>
      </cms:if> 

      <cms:if k_current_step='5' >
         <fieldset>
            <legend>Page Three (3 of 3)</legend>
            <p><label for='element_5'>Element 5:</label><cms:input type='text' name='element_5' /></p>
            <p><label for='element_6'>Element 6:</label><cms:input type='text' name='element_6'/></p>
         </fieldset>
      </cms:if> 
      
      
      <p class="nav">
         <cms:if k_current_step gt '1'><input type="submit" name="back" value="Previous"></cms:if>
         <input type="submit" name="next" value="<cms:if k_current_step=total_pages>Finish<cms:else />Next</cms:if>">
      </p>

   </cms:if>

</cms:form>

<?php COUCH::invoke(); ?>