								<cms:ignore>	
									<cms:php>
									$signontime = "<cms:date signon_date format='H:i' />";
									global $date;
									$date = date('H:i', strtotime($signontime . ' + 8 hour'));
									</cms:php>
									<cms:set overtime="<cms:date signon_date format='Y-m-d' /> <cms:php>global $date; echo $date;</cms:php>" />

									<cms:set time = "<cms:date nowtime format='Y-m-d H:i' /> - <cms:date signon_date format='Y-m-d H:i' />" />
									<cms:set signnow = "<cms:sub 'nowtime' 'signondate' format='H:i' />" scope='global' />
									Nowtime: <cms:date nowtime format='Y-m-d H:i' /><br>
									signon: <cms:show signondate format='H:i' /><br>
									sign: <cms:show time /><br><br>

									
									<cms:show addhours />
									<cms:set nowtime="<cms:date format='Y-m-d H:i' />" scope='global' />
									<cms:set nowdate="<cms:date format='Y-m-d' />" scope='global' />
									<cms:set signondate="<cms:date signon_date format='Y-m-d H:i' />" scope='global' /> 
								    minus: <cms:show minus format='H:i' /> <br>
	 								signontime: <cms:show signontime format='H:i' /> <br>
	 								nowtime: <cms:show nowtime format='H:i' /> 

	 								<!-- <cms:embed 'overdue.html' />
								 	<cms:if (is_interchanged eq '1') && (arrival_time ne '') >
									<cms:embed 'ptwise-int-report-table.html' />
									<cms:else_if (is_interchanged eq '1') && (arrival_time eq '') />
									<cms:embed 'ptwise-int-report-table.html' />
									<cms:else />
									<cms:embed 'ptwise-int-report-table.html' />
									</cms:if> -->
								</cms:ignore>




								departure_time="<cms:if my_dep_time eq '0'><cms:show my_fake_date /><cms:else /><cms:show frm_departure_time /></cms:if>"


								<!-- Working Code -->
								<cms:set nowdate="<cms:date format='H:i' />" scope='global' /> 

								<cms:set signontime="<cms:date signon_date format='H:i' />" scope='global' />
								<cms:set nowtime="<cms:date format='H:i' />" scope='global' />
 								<cms:set minus="<cms:sub nowtime signontime />" scope='global' />

								<cms:if (minus ge "<cms:show entry_diff />") >
									<cms:set overdue='1' scope='global' />
									
								<cms:else />
									<cms:set overdue='0' scope='global' />
									
								</cms:if>
							
								<cms:ignore>Setting Sign On time to calculate if the row is changing color</cms:ignore>

								<cms:ignore>Setting schedule to calculate if the row is changing color</cms:ignore>
								<cms:set schdate ="<cms:date schedule_date format='Y-m-d' />" scope='global' />
								<cms:if (schdate lt nowdate) >
									<cms:set sch_overdue='1' scope='global' />
								<cms:else />
									<cms:set sch_overdue='0' scope='global' />
								</cms:if> 
								<cms:ignore>Setting schedule to calculate if the row is changing color</cms:ignore>
								<!-- Working Code -->