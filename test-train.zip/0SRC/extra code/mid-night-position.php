<?php require_once( 'couch/cms.php' ); ?>
<!-- 

    29/06/2019
    ==========
    1. Converted all Total Fields to disabled using .gxcpl-disable
    2. Added .highlight call to Total <tr>
    3. Added blank <tr style="height: 20px !important;">...</tr> above <tr>Total</tr> for asthetics.
    4. Adjusted Ineffective and Surplus Text field | Does it need to have .gxcpl-disabled
    5. Added value="0" and readonly="1" to all Total Fields in #1
    6. Replaced value="0" with placeholder="0" as the value was being replaced with blank because of the javascript used to create the runtime addition logic

 -->
<cms:template title="Midnight Position Multi Step" clonable="1" routable='1' parent='_mdpt_' order='7'>
      <!-- DATE on Every page -->
      <cms:editable name="mdp_date" label="Mid-Night Position Date" type="datetime" allow_time='0' required="1" format="Y-m-d" order="1" />
      <!-- DATE on Every page -->
    
      <!-- Midnight Position 1 RECEIPTS -->
      <cms:editable name="rcpt_md_pt_1" label="RECEIPTS" type="group" order="2" >
            <cms:editable name="rcpt_md_pt" label="Midnight Position" type="row" >
                  <!-- ET -->
                  <cms:editable name="rcpt_wcr" label="WCR" type="text" group="rcpt_md_pt_1" class="col-md-2" order="1" />
                  <cms:editable name="rcpt_et" label="ET" type="text" group="rcpt_md_pt_1" class="col-md-2" order="2" />
                  <cms:editable name="rcpt_fc_et_tns_1" label="Forecast ET Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="3" />
                  <cms:editable name="rcpt_fc_et_tns_2" label="Forecast ET Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="4" />
                  <cms:editable name="rcpt_et_wgns" label="Wagons ET" type="text" group="rcpt_md_pt_1" class="col-md-2" order="5" />
                  <cms:editable name="rcpt_actual_et_tns_1" label="Actual ET Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="6" />
                  <cms:editable name="rcpt_actual_et_tns_2" label="Actual ET Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="7" />
                  <cms:editable name="rcpt_et_cog" label="ET Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="8" />
                  <cms:editable name="rcpt_et_ta" label="ET TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="9" />
                  <cms:editable name="rcpt_et_la" label="ET LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="10" />
                  <cms:editable name="rcpt_et_d" label="ET D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="11" />
                  <cms:editable name="rcpt_et_oth" label="ET OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="12" />
                  <cms:editable name="rcpt_et_ac" label="ET AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="13" />
                  <cms:editable name="rcpt_et_dsl" label="ET DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="14" />
                  <cms:editable name="rcpt_et_ldd" label="ET Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="15" />
                  <cms:editable name="rcpt_et_emp" label="ET Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="16" />
                  <cms:editable name="rcpt_et_mt" label="ET MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="17" />
                  <cms:editable name="rcpt_et_shortfall" label="ET Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="18" />
                  <!-- ET -->

                  <!-- NGP -->
                  <cms:editable name="rcpt_secr_ngp" label="SECR NGP" type="text" group="rcpt_md_pt_1" class="col-md-2" order="19" />
                  <cms:editable name="rcpt_ngp" label="NGP" type="text" group="rcpt_md_pt_1" class="col-md-2" order="20" />
                  <cms:editable name="rcpt_fc_ngp_tns_1" label="Forecast NGP Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="21" />
                  <cms:editable name="rcpt_fc_ngp_tns_2" label="Forecast NGP Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="22" />
                  <cms:editable name="rcpt_ngp_wgns" label="Wagons NGP" type="text" group="rcpt_md_pt_1" class="col-md-2" order="23" />
                  <cms:editable name="rcpt_actual_ngp_tns_1" label="Actual NGP Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="24" />
                  <cms:editable name="rcpt_actual_ngp_tns_2" label="Actual NGP Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="25" />
                  <cms:editable name="rcpt_ngp_cog" label="NGP Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="26" />
                  <cms:editable name="rcpt_ngp_ta" label="NGP TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="27" />
                  <cms:editable name="rcpt_ngp_la" label="NGP LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="28" />
                  <cms:editable name="rcpt_ngp_d" label="NGP D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="29" />
                  <cms:editable name="rcpt_ngp_oth" label="NGP OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="30" />
                  <cms:editable name="rcpt_ngp_ac" label="NGP AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="31" />
                  <cms:editable name="rcpt_ngp_dsl" label="NGP DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" class="col-md-2" order="32" />
                  <cms:editable name="rcpt_ngp_ldd" label="NGP Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="33" />
                  <cms:editable name="rcpt_ngp_emp" label="NGP Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="34" />
                  <cms:editable name="rcpt_ngp_mt" label="NGP MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="35" />
                  <cms:editable name="rcpt_ngp_shortfall" label="NGP Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="36" />
                  <!-- NGP -->

                  <!-- GCC -->
                  <cms:editable name="rcpt_secr_gcc" label="SECR GCC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="37" />
                  <cms:editable name="rcpt_gcc" label="GCC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="38" />
                  <cms:editable name="rcpt_fc_gcc_tns_1" label="Forecast GCC Train 1" type="text" class="col-md-2" group="rcpt_md_pt_1" order="39" />
                  <cms:editable name="rcpt_fc_gcc_tns_2" label="Forecast GCC Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="40" />
                  <cms:editable name="rcpt_gcc_wgns" label="Wagons GCC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="41" />
                  <cms:editable name="rcpt_actual_gcc_tns_1" label="Actual GCC Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="42" />
                  <cms:editable name="rcpt_actual_gcc_tns_2" label="Actual GCC Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="43" />
                  <cms:editable name="rcpt_gcc_cog" label="GCC Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="44" />
                  <cms:editable name="rcpt_gcc_ta" label="GCC TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="45" />
                  <cms:editable name="rcpt_gcc_la" label="GCC LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="46" />
                  <cms:editable name="rcpt_gcc_d" label="GCC D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="47" />
                  <cms:editable name="rcpt_gcc_oth" label="GCC OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="48" />
                  <cms:editable name="rcpt_gcc_ac" label="GCC AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="49" />
                  <cms:editable name="rcpt_gcc_dsl" label="GCC DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="50" />
                  <cms:editable name="rcpt_gcc_ldd" label="GCC Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="51" />
                  <cms:editable name="rcpt_gcc_emp" label="GCC Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="52" />
                  <cms:editable name="rcpt_gcc_mt" label="GCC MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="53" />
                  <cms:editable name="rcpt_gcc_shortfall" label="GCC Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="54" />
                  <!-- GCC -->

                  <!-- CWA -->
                  <cms:editable name="rcpt_secr_cwa" label="SECR CWA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="55" />
                  <cms:editable name="rcpt_cwa" label="CWA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="56" />
                  <cms:editable name="rcpt_fc_cwa_tns_1" label="Forecast CWA Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="57" />
                  <cms:editable name="rcpt_fc_cwa_tns_2" label="Forecast CWA Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="58" />
                  <cms:editable name="rcpt_cwa_wgns" label="Wagons CWA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="59" />
                  <cms:editable name="rcpt_actual_cwa_tns_1" label="Actual CWA Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="60" />
                  <cms:editable name="rcpt_actual_cwa_tns_2" label="Actual CWA Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="61" />
                  <cms:editable name="rcpt_cwa_cog" label="CWA Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="62" />
                  <cms:editable name="rcpt_cwa_ta" label="CWA TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="63" />
                  <cms:editable name="rcpt_cwa_la" label="CWA LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="64" />
                  <cms:editable name="rcpt_cwa_d" label="CWA D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="65" />
                  <cms:editable name="rcpt_cwa_oth" label="CWA OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="66" />
                  <cms:editable name="rcpt_cwa_ac" label="CWA AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="67" />
                  <cms:editable name="rcpt_cwa_dsl" label="CWA DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="68" />
                  <cms:editable name="rcpt_cwa_ldd" label="CWA Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="69" />
                  <cms:editable name="rcpt_cwa_emp" label="CWA Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="70" />
                  <cms:editable name="rcpt_cwa_mt" label="CWA MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="71" />
                  <cms:editable name="rcpt_cwa_shortfall" label="CWA Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="72" />
                  <!-- CWA -->

                  <!-- CAF -->
                  <cms:editable name="rcpt_secr_caf" label="SECR CAF" type="text" group="rcpt_md_pt_1" class="col-md-2" order="73" />
                  <cms:editable name="rcpt_caf" label="CAF" type="text" group="rcpt_md_pt_1" class="col-md-2" order="74" />
                  <cms:editable name="rcpt_fc_caf_tns_1" label="Forecast CAF Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="75" />
                  <cms:editable name="rcpt_fc_caf_tns_2" label="Forecast CAF Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="76" />
                  <cms:editable name="rcpt_caf_wgns" label="Wagons CAF" type="text" group="rcpt_md_pt_1" class="col-md-2" order="77" />
                  <cms:editable name="rcpt_actual_caf_tns_1" label="Actual CAF Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="78" />
                  <cms:editable name="rcpt_actual_caf_tns_2" label="Actual CAF Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="79" />
                  <cms:editable name="rcpt_caf_cog" label="CAF Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="80" />
                  <cms:editable name="rcpt_caf_ta" label="CAF TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="81" />
                  <cms:editable name="rcpt_caf_la" label="CAF LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="82" />
                  <cms:editable name="rcpt_caf_d" label="CAF D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="83" />
                  <cms:editable name="rcpt_caf_oth" label="CAF OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="84" />
                  <cms:editable name="rcpt_caf_ac" label="CAF AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="85" />
                  <cms:editable name="rcpt_caf_dsl" label="CAF DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="86" />
                  <cms:editable name="rcpt_caf_ldd" label="CAF Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="87" />
                  <cms:editable name="rcpt_caf_emp" label="CAF Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="88" />
                  <cms:editable name="rcpt_caf_mt" label="CAF MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="89" />
                  <cms:editable name="rcpt_caf_shortfall" label="CAF Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="90" />
                  <!-- CAF -->

                  <!-- BPQ -->
                  <cms:editable name="rcpt_scr_bpq" label="SCR BPQ" type="text" group="rcpt_md_pt_1" class="col-md-2" order="91" />
                  <cms:editable name="rcpt_bpq" label="BPQ" type="text" group="rcpt_md_pt_1" class="col-md-2" order="92" />
                  <cms:editable name="rcpt_fc_bpq_tns_1" label="Forecast BPQ Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="93" />
                  <cms:editable name="rcpt_fc_bpq_tns_2" label="Forecast BPQ Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="94" />
                  <cms:editable name="rcpt_bpq_wgns" label="Wagons BPQ" type="text" group="rcpt_md_pt_1" class="col-md-2" order="95" />
                  <cms:editable name="rcpt_actual_bpq_tns_1" label="Actual BPQ Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="96" />
                  <cms:editable name="rcpt_actual_bpq_tns_2" label="Actual BPQ Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="97" />
                  <cms:editable name="rcpt_bpq_cog" label="BPQ Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="98" />
                  <cms:editable name="rcpt_bpq_ta" label="BPQ TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="99" />
                  <cms:editable name="rcpt_bpq_la" label="BPQ LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="100" />
                  <cms:editable name="rcpt_bpq_d" label="BPQ D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="101" />
                  <cms:editable name="rcpt_bpq_oth" label="BPQ OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="102" />
                  <cms:editable name="rcpt_bpq_ac" label="BPQ AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="103" />
                  <cms:editable name="rcpt_bpq_dsl" label="BPQ DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="104" />
                  <cms:editable name="rcpt_bpq_ldd" label="BPQ Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="105" /> 
                  <cms:editable name="rcpt_bpq_emp" label="BPQ Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="106" />
                  <cms:editable name="rcpt_bpq_mt" label="BPQ MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="107" />
                  <cms:editable name="rcpt_bpq_shortfall" label="BPQ Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="108" />
                  <!-- BPQ -->

                  <!-- PMKT -->
                  <cms:editable name="rcpt_scr_pmkt" label="SCR PMKT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="109" />
                  <cms:editable name="rcpt_pmkt" label="PMKT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="110" />
                  <cms:editable name="rcpt_fc_pmkt_tns_1" label="Forecast PMKT Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="111" />
                  <cms:editable name="rcpt_fc_pmkt_tns_2" label="Forecast PMKT Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="112" />
                  <cms:editable name="rcpt_pmkt_wgns" label="Wagons PMKT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="113" />
                  <cms:editable name="rcpt_actual_pmkt_tns_1" label="Actual PMKT Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="114" />
                  <cms:editable name="rcpt_actual_pmkt_tns_2" label="Actual PMKT Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="115" />
                  <cms:editable name="rcpt_pmkt_cog" label="PMKT Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="116" />
                  <cms:editable name="rcpt_pmkt_ta" label="PMKT TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="117" />
                  <cms:editable name="rcpt_pmkt_la" label="PMKT LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="118" />
                  <cms:editable name="rcpt_pmkt_d" label="PMKT D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="119" />
                  <cms:editable name="rcpt_pmkt_oth" label="PMKT OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="120" />
                  <cms:editable name="rcpt_pmkt_ac" label="PMKT AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="121" />
                  <cms:editable name="rcpt_pmkt_dsl" label="PMKT DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="122" />
                  <cms:editable name="rcpt_pmkt_ldd" label="PMKT Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="123" />
                  <cms:editable name="rcpt_pmkt_emp" label="PMKT Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="124" />
                  <cms:editable name="rcpt_pmkt_mt" label="PMKT MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="125" />
                  <cms:editable name="rcpt_pmkt_shortfall" label="PMKT Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="126" />
                  <!-- PMKT -->

                  <!-- BD -->
                  <cms:editable name="rcpt_bsl_bd" label="BSL BD" type="text" group="rcpt_md_pt_1" class="col-md-2" order="127" />
                  <cms:editable name="rcpt_bd" label="BD" type="text" group="rcpt_md_pt_1" class="col-md-2" order="128" />
                  <cms:editable name="rcpt_fc_bd_tns_1" label="Forecast BD Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="129" />
                  <cms:editable name="rcpt_fc_bd_tns_2" label="Forecast BD Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="130" />
                  <cms:editable name="rcpt_bd_wgns" label="Wagons BD" type="text" group="rcpt_md_pt_1" class="col-md-2" order="131" />
                  <cms:editable name="rcpt_actual_bd_tns_1" label="Actual BD Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="132" />
                  <cms:editable name="rcpt_actual_bd_tns_2" label="Actual BD Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="133" />
                  <cms:editable name="rcpt_bd_cog" label="BD Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="134" />
                  <cms:editable name="rcpt_bd_ta" label="BD TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="135" />
                  <cms:editable name="rcpt_bd_la" label="BD LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="136" />
                  <cms:editable name="rcpt_bd_d" label="BD D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="137" />
                  <cms:editable name="rcpt_bd_oth" label="BD OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="138" />
                  <cms:editable name="rcpt_bd_ac" label="BD AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="139" />
                  <cms:editable name="rcpt_bd_dsl" label="BD DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="140" />
                  <cms:editable name="rcpt_bd_ldd" label="BD Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="141" />
                  <cms:editable name="rcpt_bd_emp" label="BD Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="142" />
                  <cms:editable name="rcpt_bd_mt" label="BD MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="143" />
                  <cms:editable name="rcpt_bd_shortfall" label="BD Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="144" />
                  <!-- BD -->

                  <!-- CNDB -->
                  <cms:editable name="rcpt_bsl_cndb" label="BSL CNDB" type="text" group="rcpt_md_pt_1" class="col-md-2" order="145" />
                  <cms:editable name="rcpt_cndb" label="CNDB" type="text" group="rcpt_md_pt_1" class="col-md-2" order="146" />
                  <cms:editable name="rcpt_fc_cndb_tns_1" label="Forecast CNDB Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="147" />
                  <cms:editable name="rcpt_fc_cndb_tns_2" label="Forecast CNDB Train 2" type="text" group=" rcpt_md_pt_1" class="col-md-2" order="148" />
                  <cms:editable name="rcpt_cndb_wgns" label="Wagons CNDB" type="text" group="rcpt_md_pt_1" class="col-md-2" order="149" />
                  <cms:editable name="rcpt_actual_cndb_tns_1" label="Actual CNDB Train 1" type="text" group="rcpt_md_pt_1" class="col-md-2" order="150" />
                  <cms:editable name="rcpt_actual_cndb_tns_2" label="Actual CNDB Train 2" type="text" group="rcpt_md_pt_1" class="col-md-2" order="151" />
                  <cms:editable name="rcpt_cndb_cog" label="CNDB Cog" type="text" group="rcpt_md_pt_1" class="col-md-2" order="152" />
                  <cms:editable name="rcpt_cndb_ta" label="CNDB TA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="153" />
                  <cms:editable name="rcpt_cndb_la" label="CNDB LA" type="text" group="rcpt_md_pt_1" class="col-md-2" order="154" />
                  <cms:editable name="rcpt_cndb_d" label="CNDB D" type="text" group="rcpt_md_pt_1" class="col-md-2" order="155" />
                  <cms:editable name="rcpt_cndb_oth" label="CNDB OTH" type="text" group="rcpt_md_pt_1" class="col-md-2" order="156" />
                  <cms:editable name="rcpt_cndb_ac" label="CNDB AC" type="text" group="rcpt_md_pt_1" class="col-md-2" order="157" />
                  <cms:editable name="rcpt_cndb_dsl" label="CNDB DSL" type="text" group="rcpt_md_pt_1" class="col-md-2" order="158" />
                  <cms:editable name="rcpt_cndb_ldd" label="CNDB Ldd" type="text" group="rcpt_md_pt_1" class="col-md-2" order="159" />
                  <cms:editable name="rcpt_cndb_emp" label="CNDB Emp" type="text" group="rcpt_md_pt_1" class="col-md-2" order="160" />
                  <cms:editable name="rcpt_cndb_mt" label="CNDB MT" type="text" group="rcpt_md_pt_1" class="col-md-2" order="161" />
                  <cms:editable name="rcpt_cndb_shortfall" label="CNDB Shortfall" type="text" group="rcpt_md_pt_1" class="col-md-12" order="162" />
                  <!-- CNDB -->
                  <!-- TOTAL -->
                  <cms:editable name="fc_tran1_total" label="Trains 1 Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="163" />
                  <cms:editable name="fc_tran2_total" label="Trains 2 Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="164" />
                  <cms:editable name="fc_wgns_total" label="Wagons Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="165" />
                  <cms:editable name="fc_tran3_total" label="Trains 3 Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="166" />
                  <cms:editable name="fc_tran4_total" label="Trains 4 Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="167" />
                  <cms:editable name="cog_total" label="Cog Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="168" />
                  <cms:editable name="ta_total" label="TA Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="169" />
                  <cms:editable name="la_total" label="LA Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="170" />
                  <cms:editable name="d_total" label="D Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="171" />
                  <cms:editable name="oth_total" label="Oth Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="172" />
                  <cms:editable name="ac_total" label="AC Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="173" />
                  <cms:editable name="dsl_total" label="DSL Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="174" />
                  <cms:editable name="ldd_total" label="Ldd Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="175" />
                  <cms:editable name="emp_total" label="Emp Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="176" />
                  <cms:editable name="mt_total" label="MT Total" type="text" group="rcpt_md_pt_1" class="col-md-2" order="177" />
                  <!-- TOTAL -->
            </cms:editable>
      </cms:editable>
      <!-- Midnight Position 1 RECEIPTS -->


      <!-- Midnight Position 1 DESPATCHES -->
      <cms:editable name="dsph_md_pt_1" label="DESPATCHES" type="group" order="3" >
            <cms:editable name="dsph_md_pt" label="Midnight Position" type="row" >
                  <!-- ET -->
                  <cms:editable name="dsph_wcr_et" label="WCR" type="text" group="dsph_md_pt_1" class="col-md-2" order="1" />
                  <cms:editable name="dsph_et" label="ET" type="text" group="dsph_md_pt_1" class="col-md-2" order="2" />
                  <cms:editable name="dsph_fc_et_tns_1" label="Forecast ET Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="3" />
                  <cms:editable name="dsph_fc_et_tns_2" label="Forecast ET Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="4" />
                  <cms:editable name="dsph_et_wgns" label="Wagons ET" type="text" group="dsph_md_pt_1" class="col-md-2" order="5" />
                  <cms:editable name="dsph_actual_et_tns_1" label="Actual ET Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="6" />
                  <cms:editable name="dsph_actual_et_tns_2" label="Actual ET Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="7" />
                  <cms:editable name="dsph_et_cog" label="ET Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="8" />
                  <cms:editable name="dsph_et_ta" label="ET TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="9" />
                  <cms:editable name="dsph_et_la" label="ET LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="10" />
                  <cms:editable name="dsph_et_d" label="ET D" type="text" group="dsph_md_pt_1" class="col-md-2" order="11" />
                  <cms:editable name="dsph_et_oth" label="ET OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="12" />
                  <cms:editable name="dsph_et_ac" label="ET AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="13" />
                  <cms:editable name="dsph_et_dsl" label="ET DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="14" />
                  <cms:editable name="dsph_et_ldd" label="ET Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="15" />
                  <cms:editable name="dsph_et_emp" label="ET Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="16" />
                  <cms:editable name="dsph_et_mt" label="ET MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="17" />
                  <cms:editable name="dsph_et_shortfall" label="ET Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="18" />
                  <!-- ET -->

                  <!-- NGP -->
                  <cms:editable name="dsph_secr_ngp" label="SECR NGP" type="text" group="dsph_md_pt_1" class="col-md-2" order="19" />
                  <cms:editable name="dsph_ngp" label="NGP" type="text" group="dsph_md_pt_1" class="col-md-2" order="20" />
                  <cms:editable name="dsph_fc_ngp_tns_1" label="Forecast NGP Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="21" />
                  <cms:editable name="dsph_fc_ngp_tns_2" label="Forecast NGP Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="22" />
                  <cms:editable name="dsph_ngp_wgns" label="Wagons NGP" type="text" group="dsph_md_pt_1" class="col-md-2" order="23" />
                  <cms:editable name="dsph_actual_ngp_tns_1" label="Actual NGP Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="24" />
                  <cms:editable name="dsph_actual_ngp_tns_2" label="Actual NGP Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="25" />
                  <cms:editable name="dsph_ngp_cog" label="NGP Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="26" />
                  <cms:editable name="dsph_ngp_ta" label="NGP TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="27" />
                  <cms:editable name="dsph_ngp_la" label="NGP LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="28" />
                  <cms:editable name="dsph_ngp_d" label="NGP D" type="text" group="dsph_md_pt_1" class="col-md-2" order="29" />
                  <cms:editable name="dsph_ngp_oth" label="NGP OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="30" />
                  <cms:editable name="dsph_ngp_ac" label="NGP AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="31" />
                  <cms:editable name="dsph_ngp_dsl" label="NGP DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="32" />
                  <cms:editable name="dsph_ngp_ldd" label="NGP Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="33" />
                  <cms:editable name="dsph_ngp_emp" label="NGP Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="34" />
                  <cms:editable name="dsph_ngp_mt" label="NGP MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="35" />
                  <cms:editable name="dsph_ngp_shortfall" label="NGP Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="36" />
                  <!-- NGP -->

                  <!-- GCC -->
                  <cms:editable name="dsph_secr_gcc" label="SECR GCC" type="text" group="dsph_md_pt_1" class="col-md-2" order="37" />
                  <cms:editable name="dsph_gcc" label="GCC" type="text" group="dsph_md_pt_1" class="col-md-2" order="38" />
                  <cms:editable name="dsph_fc_gcc_tns_1" label="Forecast GCC Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="39" />
                  <cms:editable name="dsph_fc_gcc_tns_2" label="Forecast GCC Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="40" />
                  <cms:editable name="dsph_gcc_wgns" label="Wagons GCC" type="text" group="dsph_md_pt_1" class="col-md-2" order="41" />
                  <cms:editable name="dsph_actual_gcc_tns_1" label="Actual GCC Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="42" />
                  <cms:editable name="dsph_actual_gcc_tns_2" label="Actual GCC Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="43" />
                  <cms:editable name="dsph_gcc_cog" label="GCC Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="44" />
                  <cms:editable name="dsph_gcc_ta" label="GCC TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="45" />
                  <cms:editable name="dsph_gcc_la" label="GCC LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="46" />
                  <cms:editable name="dsph_gcc_d" label="GCC D" type="text" group="dsph_md_pt_1" class="col-md-2" order="47" />
                  <cms:editable name="dsph_gcc_oth" label="GCC OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="48" />
                  <cms:editable name="dsph_gcc_ac" label="GCC AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="49" />
                  <cms:editable name="dsph_gcc_dsl" label="GCC DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="50" />
                  <cms:editable name="dsph_gcc_ldd" label="GCC Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="51" />
                  <cms:editable name="dsph_gcc_emp" label="GCC Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="52" />
                  <cms:editable name="dsph_gcc_mt" label="GCC MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="53" />
                  <cms:editable name="dsph_gcc_shortfall" label="GCC Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="54" />
                  <!-- GCC -->

                  <!-- CWA -->
                  <cms:editable name="dsph_secr_cwa" label="SECR CWA" type="text" group="dsph_md_pt_1" class="col-md-2" order="55" />
                  <cms:editable name="dsph_cwa" label="CWA" type="text" group="dsph_md_pt_1" class="col-md-2" order="56" />
                  <cms:editable name="dsph_fc_cwa_tns_1" label="Forecast CWA Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="57" />
                  <cms:editable name="dsph_fc_cwa_tns_2" label="Forecast CWA Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="58" />
                  <cms:editable name="dsph_cwa_wgns" label="Wagons CWA" type="text" group="dsph_md_pt_1" class="col-md-2" order="59" />
                  <cms:editable name="dsph_actual_cwa_tns_1" label="Actual CWA Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="60" />
                  <cms:editable name="dsph_actual_cwa_tns_2" label="Actual CWA Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="61" />
                  <cms:editable name="dsph_cwa_cog" label="CWA Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="62" />
                  <cms:editable name="dsph_cwa_ta" label="CWA TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="63" />
                  <cms:editable name="dsph_cwa_la" label="CWA LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="64" />
                  <cms:editable name="dsph_cwa_d" label="CWA D" type="text" group="dsph_md_pt_1" class="col-md-2" order="65" />
                  <cms:editable name="dsph_cwa_oth" label="CWA OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="66" />
                  <cms:editable name="dsph_cwa_ac" label="CWA AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="67" />
                  <cms:editable name="dsph_cwa_dsl" label="CWA DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="68" />
                  <cms:editable name="dsph_cwa_ldd" label="CWA Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="69" />
                  <cms:editable name="dsph_cwa_emp" label="CWA Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="70" />
                  <cms:editable name="dsph_cwa_mt" label="CWA MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="71" />
                  <cms:editable name="dsph_cwa_shortfall" label="CWA Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="72" />
                  <!-- CWA -->

                  <!-- CAF -->
                  <cms:editable name="dsph_secr_caf" label="SECR CAF" type="text" group="dsph_md_pt_1" class="col-md-2" order="73" />
                  <cms:editable name="dsph_caf" label="CAF" type="text" group="dsph_md_pt_1" class="col-md-2" order="74" />
                  <cms:editable name="dsph_fc_caf_tns_1" label="Forecast CAF Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="75" />
                  <cms:editable name="dsph_fc_caf_tns_2" label="Forecast CAF Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="76" />
                  <cms:editable name="dsph_caf_wgns" label="Wagons CAF" type="text" group="dsph_md_pt_1" class="col-md-2" order="77" />
                  <cms:editable name="dsph_actual_caf_tns_1" label="Actual CAF Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="78" />
                  <cms:editable name="dsph_actual_caf_tns_2" label="Actual CAF Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="79" />
                  <cms:editable name="dsph_caf_cog" label="CAF Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="80" />
                  <cms:editable name="dsph_caf_ta" label="CAF TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="81" />
                  <cms:editable name="dsph_caf_la" label="CAF LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="82" />
                  <cms:editable name="dsph_caf_d" label="CAF D" type="text" group="dsph_md_pt_1" class="col-md-2" order="83" />
                  <cms:editable name="dsph_caf_oth" label="CAF OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="84" />
                  <cms:editable name="dsph_caf_ac" label="CAF AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="85" />
                  <cms:editable name="dsph_caf_dsl" label="CAF DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="86" />
                  <cms:editable name="dsph_caf_ldd" label="CAF Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="87" />
                  <cms:editable name="dsph_caf_emp" label="CAF Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="88" />
                  <cms:editable name="dsph_caf_mt" label="CAF MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="89" />
                  <cms:editable name="dsph_caf_shortfall" label="CAF Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="90" />
                  <!-- CAF -->

                  <!-- BPQ -->
                  <cms:editable name="dsph_scr_bpq" label="SCR BPQ" type="text" group="dsph_md_pt_1" class="col-md-2" order="91" />
                  <cms:editable name="dsph_bpq" label="BPQ" type="text" group="dsph_md_pt_1" class="col-md-2" order="92" />
                  <cms:editable name="dsph_fc_bpq_tns_1" label="Forecast BPQ Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="93" />
                  <cms:editable name="dsph_fc_bpq_tns_2" label="Forecast BPQ Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="94" />
                  <cms:editable name="dsph_bpq_wgns" label="Wagons BPQ" type="text" group="dsph_md_pt_1" class="col-md-2" order="95" />
                  <cms:editable name="dsph_actual_bpq_tns_1" label="Actual BPQ Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="96" />
                  <cms:editable name="dsph_actual_bpq_tns_2" label="Actual BPQ Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="97" />
                  <cms:editable name="dsph_bpq_cog" label="BPQ Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="98" />
                  <cms:editable name="dsph_bpq_ta" label="BPQ TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="99" />
                  <cms:editable name="dsph_bpq_la" label="BPQ LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="100" />
                  <cms:editable name="dsph_bpq_d" label="BPQ D" type="text" group="dsph_md_pt_1" class="col-md-2" order="101" />
                  <cms:editable name="dsph_bpq_oth" label="BPQ OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="102" />
                  <cms:editable name="dsph_bpq_ac" label="BPQ AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="103" />
                  <cms:editable name="dsph_bpq_dsl" label="BPQ DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="104" />
                  <cms:editable name="dsph_bpq_ldd" label="BPQ Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="105" />
                  <cms:editable name="dsph_bpq_emp" label="BPQ Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="106" />
                  <cms:editable name="dsph_bpq_mt" label="BPQ MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="107" />
                  <cms:editable name="dsph_bpq_shortfall" label="BPQ Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="108" />
                  <!-- BPQ -->

                  <!-- PMKT -->
                  <cms:editable name="dsph_scr_pmkt" label="SCR PMKT" type="text" group="dsph_md_pt_1" class="col-md-2" order="109" />
                  <cms:editable name="dsph_pmkt" label="PMKT" type="text" group="dsph_md_pt_1" class="col-md-2" order="110" />
                  <cms:editable name="dsph_fc_pmkt_tns_1" label="Forecast PMKT Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="111" />
                  <cms:editable name="dsph_fc_pmkt_tns_2" label="Forecast PMKT Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="112" />
                  <cms:editable name="dsph_pmkt_wgns" label="Wagons PMKT" type="text" group="dsph_md_pt_1" class="col-md-2" order="113" />
                  <cms:editable name="dsph_actual_pmkt_tns_1" label="Actual PMKT Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="114" />
                  <cms:editable name="dsph_actual_pmkt_tns_2" label="Actual PMKT Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="115" />
                  <cms:editable name="dsph_pmkt_cog" label="PMKT Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="116" />
                  <cms:editable name="dsph_pmkt_ta" label="PMKT TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="117" />
                  <cms:editable name="dsph_pmkt_la" label="PMKT LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="118" />
                  <cms:editable name="dsph_pmkt_d" label="PMKT D" type="text" group="dsph_md_pt_1" class="col-md-2" order="119" />
                  <cms:editable name="dsph_pmkt_oth" label="PMKT OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="120" />
                  <cms:editable name="dsph_pmkt_ac" label="PMKT AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="121" />
                  <cms:editable name="dsph_pmkt_dsl" label="PMKT DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="122" />
                  <cms:editable name="dsph_pmkt_ldd" label="PMKT Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="123" />
                  <cms:editable name="dsph_pmkt_emp" label="PMKT Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="124" />
                  <cms:editable name="dsph_pmkt_mt" label="PMKT MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="125" />
                  <cms:editable name="dsph_pmkt_shortfall" label="PMKT Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12"  order="126" />
                  <!-- PMKT -->

                  <!-- BD -->
                  <cms:editable name="dsph_bsl_bd" label="BSL BD" type="text" group="dsph_md_pt_1" class="col-md-2" order="127" />
                  <cms:editable name="dsph_bd" label="BD" type="text" group="dsph_md_pt_1" class="col-md-2" order="128" />
                  <cms:editable name="dsph_fc_bd_tns_1" label="Forecast BD Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="129" />
                  <cms:editable name="dsph_fc_bd_tns_2" label="Forecast BD Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="130" />
                  <cms:editable name="dsph_bd_wgns" label="Wagons BD" type="text" group="dsph_md_pt_1" class="col-md-2" order="131" />
                  <cms:editable name="dsph_actual_bd_tns_1" label="Actual BD Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="132" />
                  <cms:editable name="dsph_actual_bd_tns_2" label="Actual BD Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="133" />
                  <cms:editable name="dsph_bd_cog" label="BD Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="134" />
                  <cms:editable name="dsph_bd_ta" label="BD TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="135" />
                  <cms:editable name="dsph_bd_la" label="BD LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="136" />
                  <cms:editable name="dsph_bd_d" label="BD D" type="text" group="dsph_md_pt_1" class="col-md-2" order="137" />
                  <cms:editable name="dsph_bd_oth" label="BD OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="138" />
                  <cms:editable name="dsph_bd_ac" label="BD AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="139" />
                  <cms:editable name="dsph_bd_dsl" label="BD DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="140" />
                  <cms:editable name="dsph_bd_ldd" label="BD Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="141" />
                  <cms:editable name="dsph_bd_emp" label="BD Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="142" />
                  <cms:editable name="dsph_bd_mt" label="BD MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="143" />
                  <cms:editable name="dsph_bd_shortfall" label="BD Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="144" />
                  <!-- BD -->

                  <!-- CNDB -->
                  <cms:editable name="dsph_bsl_cndb" label="BSL CNDB" type="text" group="dsph_md_pt_1" class="col-md-2" order="145" />
                  <cms:editable name="dsph_cndb" label="CNDB" type="text" group="dsph_md_pt_1" class="col-md-2" order="146" />
                  <cms:editable name="dsph_fc_cndb_tns_1" label="Forecast CNDB Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="147" />
                  <cms:editable name="dsph_fc_cndb_tns_2" label="Forecast CNDB Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="148" />
                  <cms:editable name="dsph_cndb_wgns" label="Wagons CNDB" type="text" group="dsph_md_pt_1" class="col-md-2" order="149" />
                  <cms:editable name="dsph_actual_cndb_tns_1" label="Actual CNDB Train 1" type="text" group="dsph_md_pt_1" class="col-md-2" order="150" />
                  <cms:editable name="dsph_actual_cndb_tns_2" label="Actual CNDB Train 2" type="text" group="dsph_md_pt_1" class="col-md-2" order="151" />
                  <cms:editable name="dsph_cndb_cog" label="CNDB Cog" type="text" group="dsph_md_pt_1" class="col-md-2" order="152" />
                  <cms:editable name="dsph_cndb_ta" label="CNDB TA" type="text" group="dsph_md_pt_1" class="col-md-2" order="153" />
                  <cms:editable name="dsph_cndb_la" label="CNDB LA" type="text" group="dsph_md_pt_1" class="col-md-2" order="154" />
                  <cms:editable name="dsph_cndb_d" label="CNDB D" type="text" group="dsph_md_pt_1" class="col-md-2" order="155" />
                  <cms:editable name="dsph_cndb_oth" label="CNDB OTH" type="text" group="dsph_md_pt_1" class="col-md-2" order="156" />
                  <cms:editable name="dsph_cndb_ac" label="CNDB AC" type="text" group="dsph_md_pt_1" class="col-md-2" order="157" />
                  <cms:editable name="dsph_cndb_dsl" label="CNDB DSL" type="text" group="dsph_md_pt_1" class="col-md-2" order="158" />
                  <cms:editable name="dsph_cndb_ldd" label="CNDB Ldd" type="text" group="dsph_md_pt_1" class="col-md-2" order="159" />
                  <cms:editable name="dsph_cndb_emp" label="CNDB Emp" type="text" group="dsph_md_pt_1" class="col-md-2" order="160" />
                  <cms:editable name="dsph_cndb_mt" label="CNDB MT" type="text" group="dsph_md_pt_1" class="col-md-2" order="161" />
                  <cms:editable name="dsph_cndb_shortfall" label="CNDB Shortfall" type="text" group="dsph_md_pt_1" class="col-md-12" order="162" />
                  <!-- CNDB -->
                  <!-- TOTAL -->
                  <cms:editable name="dsph_tran1_total" label="Trains 1 Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="163" />
                  <cms:editable name="dsph_tran2_total" label="Trains 2 Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="164" />
                  <cms:editable name="dsph_wgns_total" label="Wagons Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="165" />
                  <cms:editable name="dsph_tran3_total" label="Trains 3 Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="166" />
                  <cms:editable name="dsph_tran4_total" label="Trains 4 Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="167" />
                  <cms:editable name="dsph_cog_total" label="Cog Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="168" />
                  <cms:editable name="dsph_ta_total" label="TA Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="169" />
                  <cms:editable name="dsph_la_total" label="LA Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="170" />
                  <cms:editable name="dsph_d_total" label="D Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="171" />
                  <cms:editable name="dsph_oth_total" label="Oth Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="172" />
                  <cms:editable name="dsph_ac_total" label="AC Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="173" />
                  <cms:editable name="dsph_dsl_total" label="DSL Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="174" />
                  <cms:editable name="dsph_ldd_total" label="Ldd Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="175" />
                  <cms:editable name="dsph_emp_total" label="Emp Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="176" />
                  <cms:editable name="dsph_mt_total" label="MT Total" type="text" group="dsph_md_pt_1" class="col-md-2" order="177" />
                  <!-- TOTAL -->
            </cms:editable>
      </cms:editable>
      <!-- Midnight Position 1 DESPATCHES -->

      <!-- For Ineffective & Surplus -->
      <cms:editable name="inf_sur" label="Ineffective & Surplus" type="group" order="4" >
            <cms:editable name="inf_sur_row" label="Ineffective & Surplus" type="row" order="4">
                  <cms:editable name="ineffective" label="Ineffective" type="text" group="inf_sur" class="col-md-6" />
                  <cms:editable name="surplus" label="Surplus" type="text" group="inf_sur" class="col-md-6" />
            </cms:editable>
      </cms:editable>
      <!-- For Ineffective & Surplus -->
      <!-- AC/DSL Holding -->
      <cms:editable name="ac_dsl_hlding" label="AC/DSL HOLDING" type="group" order="5" >
            <cms:editable name="ac_dsl_hlding1" label="AC/DSL Holding" type="row" >
                  <cms:editable name="dsl_hld_holding" label="DSL Holding" type="text" group="ac_dsl_hlding" order="1" class="col-md-2" />
                  <cms:editable name="hld_ac_vlu" label="Holding AC Value" type="text" group="ac_dsl_hlding" order="2" class="col-md-2" />
                  <cms:editable name="hld_dsl_vlu" label="Holding DSL Value" type="text" group="ac_dsl_hlding" order="3" class="col-md-2" />
                  <cms:editable name="hld_leng_vlu1" label="Holding L/Eng Value1" type="text" group="ac_dsl_hlding" order="4" class="col-md-2" />
                  <cms:editable name="hld_leng_vlu2" label="Holding L/Eng Value2" type="text" group="ac_dsl_hlding" order="5" class="col-md-2" />
                  <cms:editable name="dsl_hld_kms" label="DSL Holding Kms" type="text" group="ac_dsl_hlding" order="6" class="col-md-2" />
                  <cms:editable name="kms_ac_vlu" label="Kms AC Value" type="text" group="ac_dsl_hlding" order="7" class="col-md-2" />
                  <cms:editable name="kms_dsl_vlu" label="Kms DSL Value" type="text" group="ac_dsl_hlding" order="8" class="col-md-2" />
                  <cms:editable name="kms_l_eng_vlu" label="Kms L/Eng Value" type="text" group="ac_dsl_hlding" order="9" class="col-md-2" />
            </cms:editable>
      </cms:editable>
      <!-- AC/DSL Holding -->

      <!-- Inter Rly Outage -->
      <cms:editable name="int_rly_outage" label="Inter Rly Outage" type="group" order="6" >
            <cms:editable name="int_rly_outage1" label="Inter Rly Outage" type="row" >
                  <cms:editable name="cr_sc" label="CR on SC" type="text" group="int_rly_outage" order="1" class="col-md-2" />
                  <cms:editable name="sc_cr" label="SC on CR" type="text" group="int_rly_outage" order="2" class="col-md-2" />
                  <cms:editable name="se_cr" label="SE on CR" type="text" group="int_rly_outage" order="3" class="col-md-2" />
                  <cms:editable name="cr_se" label="CR on SE" type="text" group="int_rly_outage" order="4" class="col-md-2" />
                  <cms:editable name="cr_sc_ac" label="CR on SC AC" type="text" group="int_rly_outage" order="5" class="col-md-2" />
                  <cms:editable name="cr_sc_mu" label="CR on SC MU" type="text" group="int_rly_outage" order="6" class="col-md-2" />
                  <cms:editable name="sc_cr_ac" label="SC on CR AC" type="text" group="int_rly_outage" order="7" class="col-md-2" />
                  <cms:editable name="sc_cr_mu" label="SC on CR MU" type="text" group="int_rly_outage" order="8" class="col-md-2" />
                  <cms:editable name="se_cr_ac" label="SE on CR AC" type="text" group="int_rly_outage" order="9" class="col-md-2" />
                  <cms:editable name="se_cr_mu" label="SE on CR MU" type="text" group="int_rly_outage" order="10" class="col-md-2" />
                  <cms:editable name="cr_se_ac" label="CR on SE AC" type="text" group="int_rly_outage" order="11" class="col-md-2" />
                  <cms:editable name="cr_se_mu" label="CR on SE MU" type="text" group="int_rly_outage" order="12" class="col-md-2" />
            </cms:editable>
      </cms:editable>
      <!-- Inter Rly Outage -->

      <!-- Holding -->
      <cms:editable name="holding" label="Holding" type="group" order="7" >
            <cms:editable name="holding1" label="Holding" type="row" >
                  <cms:editable name="hld_net" label="Holding Net" type="text" group="holding" order="1" class="col-md-2" />
                  <cms:editable name="hld_net_hr" label="Holding Net 00 hr" type="text" group="holding" order="2" class="col-md-2" />
                  <cms:editable name="hld_net_mu" label="Holding Net MU" type="text" group="holding" order="3" class="col-md-2" />
                  <cms:editable name="hld_sdg" label="Holding Sdg" type="text" group="holding" order="4" class="col-md-2" />
                  <cms:editable name="hld_sdg_hr" label="Holding Sdg 00 hr" type="text" group="holding" order="5" class="col-md-2" />
                  <cms:editable name="hld_sdg_mu" label="Holding Sdg MU" type="text" group="holding" order="6" class="col-md-2" />
                  <cms:editable name="hld_be" label="Holding B/E" type="text" group="holding" order="7" class="col-md-2" />
                  <cms:editable name="hld_be_hr" label="Holding B/E 00 hr" type="text" group="holding" order="8" class="col-md-2" />
                  <cms:editable name="hld_be_mu" label="Holding B/E MU" type="text" group="holding" order="9" class="col-md-2" />
                  <cms:editable name="hld_la" label="Holding LA" type="text" group="holding" order="10" class="col-md-2" />
                  <cms:editable name="hld_la_hr" label="Holding LA 00 hr" type="text" group="holding" order="11" class="col-md-2" />
                  <cms:editable name="hld_la_mu" label="Holding LA MU" type="text" group="holding" order="12" class="col-md-2" />
                  <cms:editable name="hld_ta" label="Holding TA" type="text" group="holding" order="13" class="col-md-2" />
                  <cms:editable name="hld_ta_hr" label="Holding TA 00 hr" type="text" group="holding" order="14" class="col-md-2" />
                  <cms:editable name="hld_ta_mu" label="Holding TA MU" type="text" group="holding" order="15" class="col-md-2" />
                  <cms:editable name="hld_dead" label="Holding Dead" type="text" group="holding" order="16" class="col-md-2" />
                  <cms:editable name="hld_dead_hr" label="Holding Dead 00 hr" type="text" group="holding" order="17" class="col-md-2" />
                  <cms:editable name="hld_dead_mu" label="Holding Dead MU" type="text" group="holding" order="18" class="col-md-2" />
                  <cms:editable name="hld_cog" label="Holding Cog" type="text" group="holding" order="19" class="col-md-2" />
                  <cms:editable name="hld_cog_hr" label="Holding Cog 00 hr" type="text" group="holding" order="20" class="col-md-2" />
                  <cms:editable name="hld_cog_mu" label="Holding Cog MU" type="text" group="holding" order="21" class="col-md-2" />
                  <cms:editable name="hld_deptl" label="Holding Deptl" type="text" group="holding" order="22" class="col-md-2" />
                  <cms:editable name="hld_deptl_hr" label="Holding Deptl 00 hr" type="text" group="holding" order="23" class="col-md-2" />
                  <cms:editable name="hld_deptl_mu" label="Holding Deptl MU" type="text" group="holding" order="24" class="col-md-2" />
                  <cms:editable name="hld_els" label="Holding ELS" type="text" group="holding" order="25" class="col-md-2" />
                  <cms:editable name="hld_els_hr" label="Holding ELS 00 hr" type="text" group="holding" order="26" class="col-md-2" />
                  <cms:editable name="hld_els_mu" label="Holding ELS MU" type="text" group="holding" order="27" class="col-md-2" />
                  <cms:editable name="hld_ts" label="Holding T/S" type="text" group="holding" order="28" class="col-md-2" />
                  <cms:editable name="hld_ts_hr" label="Holding T/S 00 hr" type="text" group="holding" order="29" class="col-md-2" />
                  <cms:editable name="hld_ts_mu" label="Holding T/S MU" type="text" group="holding" order="30" class="col-md-2" />
                  <cms:editable name="hld_acmu" label="Holding AC/MU" type="text" group="holding" order="31" class="col-md-2" />
                  <cms:editable name="hld_acmu_hr" label="Holding AC/MU 00 hr" type="text" group="holding" order="32" class="col-md-2" />
                  <cms:editable name="hld_acmu_mu" label="Holding AC/MU MU" type="text" group="holding" order="33" class="col-md-2" />
                  <cms:editable name="hld_dsl" label="Holding DSL" type="text" group="holding" order="34" class="col-md-2" />
                  <cms:editable name="hld_dsl_hr" label="Holding DSL 00 hr" type="text" group="holding" order="35" class="col-md-2" />
                  <cms:editable name="hld_dsl_mu" label="Holding DSL MU" type="text" group="holding" order="36" class="col-md-2" />
                  <cms:editable name="hld_mu" label="Holding MU" type="text" group="holding" order="37" class="col-md-2" />
                  <cms:editable name="hld_mu_hr" label="Holding MU 00 hr" type="text" group="holding" order="38" class="col-md-2" />
                  <cms:editable name="hld_mu_mu" label="Holding MU MU" type="text" group="holding" order="39" class="col-md-2" />
            </cms:editable>
      </cms:editable>
      <!-- Holding -->

      <!-- PUNCTUALITY  -->
      <cms:editable name="punc" label="Puncualtilty" type="group" order="8">
            <cms:editable name="punc_row" type="row" >
                  <cms:editable name="mexp_punc1" label="M/Exp Punctuality First" group="punc" type="text" order="2" class="col-md-3" />
                  <cms:editable name="mexp_run_punc1" label="M/Exp Run First" type="text" group="punc" order="3" class="col-md-3" />
                  <cms:editable name="mexp_lost_punc1" label="M/Exp Lost First" type="text" group="punc" order="4" class="col-md-3" />
                  <cms:editable name="mexp_trno_punc1" label="M/Exp Train Number First" type="text" group="punc" order="5" class="col-md-3" />
                  <cms:editable name="pass_punc1" label="Pass Punctuality First" type="text" group="punc" order="6" class="col-md-3" />
                  <cms:editable name="pass_run_punc1" label="Pass Run First" type="text" group="punc" order="7" class="col-md-3" />
                  <cms:editable name="pass_lost_punc1" label="Pass Lost First" type="text" group="punc" order="8" class="col-md-3" />
                  <cms:editable name="pass_trno_punc1" label="Pass Train Number First" type="text" group="punc" order="9" class="col-md-3" />
            </cms:editable>
      </cms:editable>
      <!-- PUNCTUALITY  -->

      <!-- PUNCTUALITY1  -->
      <cms:editable name="punctuation1" label='Punctuality 1' type="group" order="9" >
            <cms:editable name="punc_row" type="row" >
                  <cms:editable name="mexp_punc2" label="M/Exp Punctuality Second" type="text" order="2" group="punctuation1" class="col-md-3" />
                  <cms:editable name="mexp_run_punc2" label="M/Exp Run Second" type="text" order="3" group="punctuation1" class="col-md-3" />
                  <cms:editable name="mexp_lost_punc2" label="M/Exp Lost Second" type="text" order="4" group="punctuation1" class="col-md-3" />
                  <cms:editable name="mexp_trno_punc2" label="M/Exp Train Number Second" type="text" order="5" group="punctuation1" class="col-md-3" />
                  <cms:editable name="pass_punc2" label="Pass Punctuality Second" type="text" order="6" group="punctuation1" class="col-md-3" />
                  <cms:editable name="pass_run_punc2" label="Pass Run Second" type="text" order="7" group="punctuation1" class="col-md-3" />
                  <cms:editable name="pass_lost_punc2" label="Pass Lost Second" type="text" order="8" group="punctuation1" class="col-md-3" />
                  <cms:editable name="pass_trno_punc2" label="Pass Train Number Second" type="text" order="9" group="punctuation1" class="col-md-3" />
            </cms:editable>
      </cms:editable>
      <!-- PUNCTUALITY1  -->

      <!-- STOCK HOLDING1 -->
      <cms:editable name="stck_hld1" label="Stock Holding " type="group" order="10" >
            <cms:editable name="stck_row" type="row">
                  <cms:editable name="recd_stck1" label="Recd Stock Holding First" type="text" group="stck_hld1" order="1" class="col-md-2" />
                  <cms:editable name="recd_ldd_boxn1" label="Recd Ldd BOXN First" type="text" group="stck_hld1" order="2" class="col-md-2" />
                  <cms:editable name="recd_emp_boxn1" label="Recd Emp BOXN First" type="text" group="stck_hld1" order="3" class="col-md-2" />
                  <cms:editable name="recd_ldd_ot1" label="Recd Ldd OT First" type="text" group="stck_hld1" order="4" class="col-md-2" />
                  <cms:editable name="recd_emp_ot1" label="Recd Emp OT First" type="text" group="stck_hld1" order="5" class="col-md-2" />
                  <cms:editable name="recd_ldd_jumbo1" label="Recd Ldd Jumbo First" type="text" group="stck_hld1" order="6" class="col-md-2" />
                  <cms:editable name="recd_emp_jumbo1" label="Recd Emp Jumbo First" type="text" group="stck_hld1" order="7" class="col-md-2" />
                  <cms:editable name="recd_ldd_steel1" label="Recd Ldd Steel First" type="text" group="stck_hld1" order="8" class="col-md-2" />
                  <cms:editable name="recd_emp_steel1" label="Recd Emp Steel First" type="text" group="stck_hld1" order="9" class="col-md-2" />
                  <cms:editable name="recd_ldd_cont1" label="Recd Ldd Cont First" type="text" group="stck_hld1" order="10" class="col-md-2" />
                  <cms:editable name="recd_emp_cont1" label="Recd Emp Cont First" type="text" group="stck_hld1" order="11" class="col-md-2" />

                  <cms:editable name="desp_stck1" label="Desp Stock Holding First" type="text" group="stck_hld1" order="12" class="col-md-2" />
                  <cms:editable name="desp_ldd_boxn1" label="Desp Ldd BOXN First" type="text" group="stck_hld1" order="13" class="col-md-2" />
                  <cms:editable name="desp_emp_boxn1" label="Desp Emp BOXN First" type="text" group="stck_hld1" order="14" class="col-md-2" />
                  <cms:editable name="desp_ldd_ot1" label="Desp Ldd OT First" type="text" group="stck_hld1" order="15" class="col-md-2" />
                  <cms:editable name="desp_emp_ot1" label="Desp Emp OT First" type="text" group="stck_hld1" order="16" class="col-md-2" />
                  <cms:editable name="desp_ldd_jumbo1" label="Desp Ldd Jumbo First" type="text" group="stck_hld1" order="17" class="col-md-2" />
                  <cms:editable name="desp_emp_jumbo1" label="Desp Emp Jumbo First" type="text" group="stck_hld1" order="18" class="col-md-2" />
                  <cms:editable name="desp_ldd_steel1" label="Desp Ldd Steel First" type="text" group="stck_hld1" order="19" class="col-md-2" />
                  <cms:editable name="desp_emp_steel1" label="Desp Emp Steel First" type="text" group="stck_hld1" order="20" class="col-md-2" />
                  <cms:editable name="desp_ldd_cont1" label="Desp Ldd Cont First" type="text" group="stck_hld1" order="21" class="col-md-2" />
                  <cms:editable name="desp_emp_cont1" label="Desp Emp Cont First" type="text" group="stck_hld1" order="22" class="col-md-2" />
            </cms:editable>
      </cms:editable>
      <!-- STOCK HOLDING1 -->
      <!-- Loading -->
      <cms:editable name="loading" label="Loading" type="group" order="11" >
            <cms:editable name="lding_row" type="row" >
                  <cms:editable name="coal" label="Coal" type="text" group="loading" order="1" class="col-md-3" />
                  <cms:editable name="coal_fc_rake" label="Coal Forecasted Rakes" type="text" group="loading" order="2" class="col-md-3" />
                  <cms:editable name="coal_fc_wgn" label="Coal Forecasted Wagons" type="text" group="loading" order="3" class="col-md-3" />
                  <cms:editable name="coal_ld_rake" label="Coal Loading Rakes" type="text" group="loading" order="4" class="col-md-3" />
                  <cms:editable name="coal_ld_wgn" label="Coal Loading Wagons" type="text" group="loading" order="5" class="col-md-3" />
                  <cms:editable name="coal_rejc" label="Coal Rejection" type="text" group="loading" order="6" class="col-md-3" />
                  <cms:editable name="coal_tdays_fc" label="Coal Todays Forecast" type="text" group="loading" order="7" class="col-md-3" />

                  <cms:editable name="cement" label="Cement" type="text" group="loading" order="8" class="col-md-3" />
                  <cms:editable name="cement_fc_rake" label="Cement Forecasted Rakes" type="text" group="loading" order="9" class="col-md-3" />
                  <cms:editable name="cement_fc_wgn" label="Cement Forecasted Wagons" type="text" group="loading" order="10" class="col-md-3" />
                  <cms:editable name="cement_ld_rake" label="Cement Loading Rakes" type="text" group="loading" order="11" class="col-md-3" />
                  <cms:editable name="cement_ld_wgn" label="Cement Loading Wagons" type="text" group="loading" order="12" class="col-md-3" />
                  <cms:editable name="cement_rejc" label="Cement Rejection" type="text" group="loading" order="13" class="col-md-3" />
                  <cms:editable name="cement_tdays_fc" label="Cement Todays Forecast" type="text" group="loading" order="14" class="col-md-3" />

                  <cms:editable name="others" label="Others" type="text" group="loading" order="15" class="col-md-3" />
                  <cms:editable name="others_fc_rake" label="Others Forecasted Rakes" type="text" group="loading" order="16" class="col-md-3" />
                  <cms:editable name="others_fc_wgn" label="Others Forecasted Wagons" type="text" group="loading" order="17" class="col-md-3" />
                  <cms:editable name="others_ld_rake" label="Others Loading Rakes" type="text" group="loading" order="18" class="col-md-3" />
                  <cms:editable name="others_ld_wgn" label="Others Loading Wagons" type="text" group="loading" order="19" class="col-md-3" />
                  <cms:editable name="others_rejc" label="Others Rejection" type="text" group="loading" order="20" class="col-md-3" />
                  <cms:editable name="others_tdays_fc" label="Others Todays Forecast" type="text" group="loading" order="21" class="col-md-3" />

                  <cms:editable name="total_fc_rake" label="Total Forecasted Rakes" type="text" group="loading" order="22" class="col-md-3" />
                  <cms:editable name="total_fc_wgn" label="Total Forecasted Wagons" type="text" group="loading" order="23" class="col-md-3" />
                  <cms:editable name="total_ld_rake" label="Total Loading Rakes" type="text" group="loading" order="24" class="col-md-3" />
                  <cms:editable name="total_ld_wgn" label="Total Loading Wagons" type="text" group="loading" order="25" class="col-md-3" />
                  <cms:editable name="total_rejc" label="Total Rejection" type="text" group="loading" order="26" class="col-md-3" />
                  <cms:editable name="total_tdays_fc" label="Total Todays Forecast" type="text" group="loading" order="27" class="col-md-3" />
            </cms:editable>
      </cms:editable>
      <!-- Loading -->
      <!-- DIST WAGONS1 -->
      <cms:editable name="dist_wgns1" label="Dist Wagons" type="group" order="12" >
            <cms:editable name="wgns_row" type="row">
                  <cms:editable name="avai_wgns1" label="Available First" type="text" group="dist_wgns1" order="1" class="col-md-4" />
                  <cms:editable name="plce_wgns1" label="Placed First" type="text" group="dist_wgns1" order="2" class="col-md-4" />
                  <cms:editable name="unld_wgns1" label="Unldd First" type="text" group="dist_wgns1" order="3" class="col-md-4" />
            </cms:editable>
      </cms:editable>
      <!-- DIST WAGONS1 -->

      <!-- PUNCTUALITY2  -->
      <cms:editable name="punctuation2" label='Punctuality 2' type="group" order="13" >
            <cms:editable name="punc_row" label="Punctuality" type="row" >
                  <cms:editable name="mexp_punc3" label="M/Exp Punctuality Third" type="text" order="2" group="punctuation2" class="col-md-3" />
                  <cms:editable name="mexp_run_punc3" label="M/Exp Run Third" type="text" order="3" group="punctuation2" class="col-md-3" />
                  <cms:editable name="mexp_lost_punc3" label="M/Exp Lost Third" type="text" order="4" group="punctuation2" class="col-md-3" />
                  <cms:editable name="mexp_trno_punc3" label="M/Exp Train Number Third" type="text" order="5" group="punctuation2" class="col-md-3" />
                  <cms:editable name="pass_punc3" label="Pass Punctuality Third" type="text" order="6" group="punctuation1" class="col-md-3" />
                  <cms:editable name="pass_run_punc3" label="Pass Run Third" type="text" order="7" group="punctuation2" class="col-md-3" />
                  <cms:editable name="pass_lost_punc3" label="Pass Lost Third" type="text" order="8" group="punctuation2" class="col-md-3" />
                  <cms:editable name="pass_trno_punc3" label="Pass Train Number Third" type="text" order="9" group="punctuation1" class="col-md-3" />
            </cms:editable>
      </cms:editable>
      <!-- PUNCTUALITY2  -->
      <!-- DIST WAGONS2 -->
      <cms:editable name="dist_wgns2" label="Dist Wagons 1" type="group" order="14" >
            <cms:editable name="wgns_row" type="row">
                  <cms:editable name="avai_wgns2" label="Available Second" type="text" group="dist_wgns2" order="1" class="col-md-4" />
                  <cms:editable name="plce_wgns2" label="Placed Second" type="text" group="dist_wgns2" order="2" class="col-md-4" />
                  <cms:editable name="unld_wgns2" label="Unldd Second" type="text" group="dist_wgns2" order="3" class="col-md-4" />
            </cms:editable>
      </cms:editable>
      <!-- DIST WAGONS2 -->
      <!-- STOCK HOLDING2 -->
      <cms:editable name="stck_hld2" label="Stock Holding 1" type="group" order="15" >
            <cms:editable name="stck_row" type="row">
                  <cms:editable name="recd_stck2" label="Recd Stock Holding Second" type="text" group="stck_hld2" order="1" class="col-md-2" />
                  <cms:editable name="recd_ldd_boxn2" label="Recd Ldd BOXN Second" type="text" group="stck_hld2" order="2" class="col-md-2" />
                  <cms:editable name="recd_emp_boxn2" label="Recd Emp BOXN Second" type="text" group="stck_hld2" order="3" class="col-md-2" />
                  <cms:editable name="recd_ldd_ot2" label="Recd Ldd OT Second" type="text" group="stck_hld2" order="4" class="col-md-2" />
                  <cms:editable name="recd_emp_ot2" label="Recd Emp OT Second" type="text" group="stck_hld2" order="5" class="col-md-2" />
                  <cms:editable name="recd_ldd_jumbo2" label="Recd Ldd Jumbo Second" type="text" group="stck_hld2" order="6" class="col-md-2" />
                  <cms:editable name="recd_emp_jumbo2" label="Recd Emp Jumbo Second" type="text" group="stck_hld2" order="7" class="col-md-2" />
                  <cms:editable name="recd_ldd_steel2" label="Recd Ldd Steel Second" type="text" group="stck_hld2" order="8" class="col-md-2" />
                  <cms:editable name="recd_emp_steel2" label="Recd Emp Steel Second" type="text" group="stck_hld2" order="9" class="col-md-2" />
                  <cms:editable name="recd_ldd_cont2" label="Recd Ldd Cont Second" type="text" group="stck_hld2" order="10" class="col-md-2" />
                  <cms:editable name="recd_emp_cont2" label="Recd Emp Cont Second" type="text" group="stck_hld2" order="11" class="col-md-2" />

                  <cms:editable name="desp_stck2" label="Desp Stock Holding Second" type="text" group="stck_hld2" order="12" class="col-md-2" />
                  <cms:editable name="desp_ldd_boxn2" label="Desp Ldd BOXN Second" type="text" group="stck_hld2" order="13" class="col-md-2" />
                  <cms:editable name="desp_emp_boxn2" label="Desp Emp BOXN Second" type="text" group="stck_hld2" order="14" class="col-md-2" />
                  <cms:editable name="desp_ldd_ot2" label="Desp Ldd OT Second" type="text" group="stck_hld2" order="15" class="col-md-2" />
                  <cms:editable name="desp_emp_ot2" label="Desp Emp OT Second" type="text" group="stck_hld2" order="16" class="col-md-2" />
                  <cms:editable name="desp_ldd_jumbo2" label="Desp Ldd Jumbo Second" type="text" group="stck_hld2" order="17" class="col-md-2" />
                  <cms:editable name="desp_emp_jumbo2" label="Desp Emp Jumbo Second" type="text" group="stck_hld2" order="18" class="col-md-2" />
                  <cms:editable name="desp_ldd_steel2" label="Desp Ldd Steel Second" type="text" group="stck_hld2" order="19" class="col-md-2" />
                  <cms:editable name="desp_emp_steel2" label="Desp Emp Steel Second" type="text" group="stck_hld2" order="20" class="col-md-2" />
                  <cms:editable name="desp_ldd_cont2" label="Desp Ldd Cont Second" type="text" group="stck_hld2" order="21" class="col-md-2" />
                  <cms:editable name="desp_emp_cont2" label="Desp Emp Cont Second" type="text" group="stck_hld2" order="22" class="col-md-2" />
            </cms:editable>
      </cms:editable>
      <!-- STOCK HOLDING2 -->

      <!-- Custom Routes -->
      <cms:route name='list_mnp1' path='' />
      <cms:route name='create_mnp1' path='create' />
      <cms:route name='edit_mnp1' path='{:id}/edit' >
            <cms:route_validators id='non_zero_integer' />
      </cms:route>
      <cms:route name='delete_mnp1' path='{:id}/delete' >
            <cms:route_validators id='non_zero_integer' />
      </cms:route>
      <!-- Custom Routes -->
</cms:template>
      <cms:embed 'header.html' />
      <!-- Content Here -->
      <div class="container-fluid">
            <!-- <div class="row"> -->
            <div class="gxcpl-ptop-30"></div>

                <!-- Section Title -->
                  <div class="col-md-12">
                        <h4 class="gxcpl-no-margin">
                              MID-NIGHT POSITION
                              <div class="gxcpl-ptop-10"></div>
                              <div class="gxcpl-divider-dark"></div>
                              <div class="gxcpl-ptop-20"></div>
                        </h4>
                  </div>
                  <!-- Section Title -->

                  <!-- Section Divider -->
                  <div class="gxcpl-ptop-10"></div>
                  <!-- <div class="gxcpl-divider-dark"></div> -->
                  <div class="gxcpl-ptop-10"></div>
                  <!-- Section Divider -->
                  <!-- Regular form. Just make sure the method is 'post' -->
                  <cms:if k_current_step='5' >
                  <cms:set submit_success="<cms:get_flash 'submit_success' />" />
                  <cms:if submit_success >
                        <div class="col-md-12">
                              <div class="alert alert-success">
                                    <strong>Success! </strong>Midnight Position created successfully.
                              </div>
                        </div>
                  </cms:if>
                  </cms:if>
                  <cms:form 
                      masterpage=k_template_name
                      mode='create'
                      enctype='multipart/form-data'
                      method='post'
                      anchor='0' >
                  <cms:if k_success >
                        <cms:db_persist_form
                              _invalidate_cache='0'
                              k_page_title="<cms:date mpyest />"
                              k_page_name="<cms:show k_page_title />"
                        />
                        <cms:if k_success >
                              <cms:set_flash name='submit_success' value='1' />  
                        </cms:if>
                  </cms:if>

                  <cms:if k_error >
                        <div class="row">
                              <cms:each k_error >
                                    <div class="col-md-4">
                                          <div class="alert alert-danger">
                                                <cms:show item />
                                          </div>
                                    </div>
                              </cms:each>
                        </div>
                  </cms:if>

                  <cms:set total_pages = '5' />

                  <cms:embed 'multi_form_handler.html' />
               
                  <cms:if k_current_step gt total_pages >
                        <h2>Thank you for contacting us</h2>
                        <h4>Current Values:</h4>
                        <p>
                           Element 1: <cms:show frm_element_1 /><br>
                           Element 2: <cms:show frm_element_2 /><br>
                           Element 3: <cms:show frm_element_3 /><br>
                           Element 4: <cms:show frm_element_4 /><br>
                           Element 5: <cms:show frm_element_5 />
                        </p>     
                  <cms:else />    
                  <cms:set mpyest="<cms:date return='yesterday' format='Y-m-d' />" scope="global" /> 
                  <div class="row">
                        <div class="col-md-12">
                              <div class="gxcpl-card">
                                    <div class="gxcpl-card-header">
                                          <h5>
                                                Operating Performance of Date : 
                                                <cms:hide>
                                                    <cms:input type='bound' name="mdp_date" />
                                                </cms:hide>
                                                <input type='date' name="f_mdp_date" class="gxcpl-input-text" value="<cms:date return='yesterday' format='Y-m-d' />" style="width: auto;" />
                                          </h5>
                                    </div>
                              </div>
                        </div>
                  </div>
                  <div class="gxcpl-ptop-20"></div>
                  <cms:if k_current_step='1' >
                        <div class="row">
                              <!-- Mid-Night Position -->
                              <div class="col-md-12">
                                    <!-- Card -->
                                    <div class="gxcpl-card">
                                          <!-- Body -->
                                          <!-- Receipts -->
                                          <div class="gxcpl-card-body">
                                                <h4 class="gxcpl-padding-10">RECEIPTS</h4>
                                                <table class="gxcpl-table" width="100%">
                                                      <tr>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td colspan="4" class="gxcpl-fw-700 text-center">Forecast
                                                            </td>
                                                            <td colspan="13" class="gxcpl-fw-700 text-center">Actual
                                                            </td>
                                                            <td>&nbsp;</td>
                                                      </tr>
                                                      <tr>
                                                            <td width="6%" class="gxcpl-fw-700 text-center">
                                                                  Rly./Divn
                                                            </td>
                                                            <td width="6%" class="gxcpl-fw-700 text-center">
                                                                  Intch pt.
                                                            </td>
                                                            <td width="7%" colspan="3" class="gxcpl-fw-700 text-center">
                                                                  Trains
                                                            </td>
                                                            <td width="6%" class="gxcpl-fw-700 text-center">
                                                                  Wagons
                                                            </td>
                                                            <td width="7%" colspan="3" class="gxcpl-fw-700 text-center">
                                                                  Trains
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Cog
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  TA
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  LA
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  D
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Oth
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  AC
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  DSL
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Ldd
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Emp
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  MT
                                                            </td>
                                                            <td width="28%" class="gxcpl-fw-700 text-center">     
                                                                  Shortfall (Remarks)
                                                            </td>
                                                      </tr>
                                                      <!-- ET Receipts -->


                                                      <cms:set my_template_name = k_template_name />
                                                      <cms:set my_page_title="<cms:date mpyest />" />
                                                  
                                                      <cms:php>
                                                            global $CTX, $FUNCS;
                                                            $name = $FUNCS->get_clean_url( "<cms:show my_page_title />" );
                                                            $CTX->set( 'my_page_name', $name ); 
                                                      </cms:php>
                                                  
                                                      <cms:set my_page_id='' 'global' />
                                                      <cms:pages masterpage=my_template_name page_name=my_page_name limit='1' show_future_entries='1'>
                                                            <cms:set my_page_id=k_page_id  'global' />
                                                      </cms:pages>
                                                  
                                                      <cms:if my_page_id=''>
                                                      
                                                            <cms:if k_success >
                                                                  <cms:db_persist_form _invalidate_cache='0' k_page_title="<cms:date mpyest />" k_page_name="<cms:show k_page_title />" />
                                                                  <cms:if k_success >
                                                                        <cms:set_flash name='submit_success_transport' value='1' />
                                                                </cms:if>
                                                            </cms:if>

                                                      <cms:if k_error >
                                                          <!-- <div class="row"> -->
                                                            <div class="col-md-3">
                                                                  <div class="alert alert-danger">
                                                                        <cms:each k_error >
                                                                            <cms:show item /><br>
                                                                        </cms:each>
                                                                  </div>
                                                            </div>  
                                                          <!-- </div> -->
                                                      </cms:if>
                                                      <!-- <div class="gxcpl-ptop-10"></div> -->
                                                      <cms:else />
                                                            <div class="col-md-3" style="position: absolute; right: 0px;">
                                                                  <div class="alert alert-danger">
                                                                        <strong>ERROR:</strong> Data already exists in transportation!
                                                                  </div>
                                                            </div>
                                                      </cms:if>
                                                      <tr>
                                                            <!-- WCR Hidden -->
                                                            <td class="text-center">
                                                                  WCR
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_wcr"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_wcr" value="WCR" hidden />
                                                            </td>
                                                            <!-- WCR Hidden -->
                                                            <!-- ET Hidden -->
                                                            <td class="text-center">
                                                                  ET
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_et"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_et" value="ET" hidden />
                                                            </td>
                                                            <!-- ET Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_et_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_et_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_et_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_et_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_et_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_et_cog" />
                                                            </td>
                                                            <td>  
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_et_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_et_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_et_d" />
                                                            </td>    
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_et_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_et_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_et_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_et_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_et_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_et_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_et_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- ET Receipts -->
                                                      <!-- NGP Receipts -->
                                                      <tr>
                                                            <!-- SECR Hidden -->
                                                            <td rowspan="4" class="text-center">
                                                                  SECR
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_secr_ngp"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_secr_ngp" value="SECR" hidden />
                                                            </td>
                                                            <!-- SECR Hidden -->
                                                            <!-- NGP Hidden -->
                                                            <td class="text-center">   
                                                                  NGP
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_ngp"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_ngp" value="NGP" hidden />
                                                            </td>
                                                            <!-- NGP Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_ngp_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_ngp_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_ngp_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_ngp_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_ngp_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_ngp_cog" />
                                                            </td>    
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_ngp_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_ngp_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_ngp_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_ngp_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_ngp_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_ngp_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_ngp_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_ngp_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_ngp_mt" />
                                                            </td>    
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_ngp_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- NGP Receipts -->
                                                      <!-- GCC Receipts -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SECR Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_secr_gcc"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_secr_gcc" value="SECR" hidden />
                                                                  <!-- SECR Hidden -->
                                                                  GCC
                                                                  <!-- GCC Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_gcc"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_gcc" value="GCC" hidden />
                                                                  <!-- GCC Hidden -->
                                                            </td>
                                                            <td width="3%">   
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_gcc_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_gcc_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_gcc_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_gcc_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_gcc_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_gcc_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_gcc_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_gcc_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_gcc_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_gcc_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_gcc_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_gcc_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_gcc_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_gcc_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_gcc_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_gcc_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- GCC Receipts -->
                                                      <!-- CWA Receipts -->
                                                      <tr>
                                                            <td class="text-center">
                                                            <!-- SECR Hidden-->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_secr_cwa"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_secr_cwa" value="SECR" hidden />
                                                                  <!-- SECR Hidden -->
                                                                  CWA
                                                                  <!-- CWA Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_cwa"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_cwa" value="CWA" hidden />
                                                                  <!-- CWA Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_cwa_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_cwa_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_cwa_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_cwa_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_cwa_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_cwa_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_cwa_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_cwa_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_cwa_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_cwa_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_cwa_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_cwa_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_cwa_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_cwa_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_cwa_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_cwa_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- CWA Receipts -->
                                                      <!-- CAF Receipts -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SECR Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_secr_caf"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_secr_caf" value="SECR" hidden />
                                                                  <!-- SECR Hidden -->
                                                                  CAF
                                                                  <!-- CAF Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_caf"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_caf" value="CAF" hidden />
                                                                  <!-- CAF Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_caf_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_caf_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_caf_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_caf_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_caf_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_caf_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_caf_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_caf_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_caf_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_caf_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_caf_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_caf_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_caf_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_caf_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_caf_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_caf_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- CAF Receipts -->
                                                      <!-- BPQ Receipts -->
                                                      <tr>
                                                            <!-- SCR Hidden -->
                                                            <td rowspan="2" class="text-center">
                                                            SCR
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_scr_bpq"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_scr_bpq" value="SCR" hidden />
                                                            </td>
                                                            <!-- SCR Hidden -->
                                                            <!-- BPQ Hidden -->
                                                            <td class="text-center">
                                                                  BPQ
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_bpq"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_bpq" value="BPQ" hidden />
                                                            </td>
                                                            <!-- BPQ Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_bpq_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_bpq_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_bpq_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_bpq_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_bpq_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_bpq_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_bpq_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_bpq_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_bpq_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_bpq_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_bpq_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_bpq_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_bpq_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_bpq_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_bpq_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_bpq_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- BPQ Receipts -->
                                                      <!-- PMKT Receipts -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SCR Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="rcpt_scr_pmkt"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_scr_pmkt" value="SCR" hidden />
                                                                  <!-- SCR Hidden -->
                                                                  PMKT
                                                                  <!-- PMKT Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="rcpt_pmkt"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_pmkt" value="PMKT" hidden />
                                                                  <!-- PMKT Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_pmkt_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_pmkt_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_pmkt_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_pmkt_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_pmkt_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_pmkt_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_pmkt_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_pmkt_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_pmkt_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_pmkt_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_pmkt_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_pmkt_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_pmkt_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_pmkt_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_pmkt_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_pmkt_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- PMKT Receipts -->
                                                      <!-- BD Receipts -->
                                                      <tr>
                                                            <!-- BSL Hidden -->
                                                            <td class="text-center" rowspan="2">
                                                                   BSL
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="rcpt_bsl_bd"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_bsl_bd" value="BSL" hidden />
                                                            </td>
                                                            <!-- BSL Hidden -->
                                                            <!-- BD Hidden -->
                                                            <td class="text-center">
                                                                  BD
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="rcpt_bd"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_bd" value="BD" hidden />
                                                            </td>
                                                            <!-- BD Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_bd_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_bd_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_bd_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_bd_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_bd_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_bd_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_bd_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_bd_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_bd_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_bd_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_bd_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_bd_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_bd_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_bd_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_bd_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_bd_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- BD Receipts -->
                                                      <!-- CNDB Receipts -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- BSL Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="rcpt_bsl_cndb"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_bsl_cndb" value="BSL" hidden />
                                                                  <!-- BSL Hidden -->
                                                                  CNDB
                                                                  <!-- CNDB Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="rcpt_cndb"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_rcpt_cndb" value="CNDB" hidden />
                                                                  <!-- CNDB Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-1" name="rcpt_fc_cndb_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-2" name="rcpt_fc_cndb_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-wgns" name="rcpt_cndb_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-3" name="rcpt_actual_cndb_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">  
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt-tr-4" name="rcpt_actual_cndb_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_cog" name="rcpt_cndb_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ta" name="rcpt_cndb_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_la" name="rcpt_cndb_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_d" name="rcpt_cndb_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_oth" name="rcpt_cndb_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ac" name="rcpt_cndb_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_dsl" name="rcpt_cndb_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_ldd" name="rcpt_cndb_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_emp" name="rcpt_cndb_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text rcpt_mt" name="rcpt_cndb_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="rcpt_cndb_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- CNDB Receipts -->
                                                      <tr style="height: 10px !important;"></tr>
                                                      <!-- Total Receipts -->
                                                      <tr class="highlight">
                                                            <td class="text-center" colspan="2">
                                                                  <strong>Total</strong>
                                                            </td>
                                                            <td>
                                                                  <cms:input id="fc_tran1_total" name="fc_tran1_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" type="bound" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  =
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="fc_tran2_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="fc_tran2_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="fc_wgns_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="fc_wgns_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="fc_tran3_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="fc_tran3_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  =
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="fc_tran4_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="fc_tran4_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="cog_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="cog_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="ta_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="ta_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="la_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="la_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="d_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="d_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="oth_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="oth_total" placeholder="0" readonly='1'  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="ac_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="ac_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsl_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsl_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="ldd_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="ldd_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="emp_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="emp_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="mt_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="mt_total" placeholder="0" readonly='1' />
                                                            </td>
                                                            <td>
                                                                  <input type='text' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="" placeholder="0" readonly='1' />
                                                            </td>
                                                      </tr>
                                                      <!-- Total Receipts -->
                                                </table>  
                                          </div>
                                          <!-- Receipts -->
                                          <!-- Despathces -->
                                          <div class="gxcpl-card-body">
                                                <h4 class="gxcpl-padding-10">DESPATCHES</h4>
                                                <table class="gxcpl-table" width="100%">
                                                      <tr>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td colspan="4" class="gxcpl-fw-700 text-center">
                                                            Forecast
                                                            </td>
                                                            <td colspan="13" class="gxcpl-fw-700 text-center">
                                                            Actual
                                                            </td>
                                                            <td>&nbsp;</td>
                                                      </tr>
                                                      <tr>
                                                            <td width="6%" class="gxcpl-fw-700 text-center">
                                                                  Rly./Divn
                                                            </td>
                                                            <td width="6%" class="gxcpl-fw-700 text-center">
                                                                  Intch pt.
                                                            </td>
                                                            <td width="7%" colspan="3" class="gxcpl-fw-700 text-center">   
                                                                  Trains
                                                            </td>
                                                            <td width="6%" class="gxcpl-fw-700 text-center">
                                                                  Wagons
                                                            </td>
                                                            <td width="7%" colspan="3" class="gxcpl-fw-700 text-center">
                                                                  Trains
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Cog
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  TA
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  LA
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">   
                                                                  D
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Oth
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">   
                                                                  AC
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  DSL
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Ldd
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  Emp
                                                            </td>
                                                            <td width="4%" class="gxcpl-fw-700 text-center">
                                                                  MT
                                                            </td>
                                                            <td width="28%" class="gxcpl-fw-700 text-center">       
                                                                  Shortfall (Remarks)
                                                            </td>
                                                      </tr>
                                                      <!-- ET Despatches -->
                                                      <tr>
                                                            <!-- WCR Hidden -->
                                                            <td class="text-center">   
                                                                  WCR
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_wcr_et"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_wcr_et" value="WCR" hidden />
                                                            </td>
                                                            <!-- WCR Hidden -->
                                                            <!-- ET Hidden -->
                                                            <td class="text-center">   
                                                                  ET
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_et"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_et" value="ET" hidden />
                                                            </td>
                                                            <!-- ET Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_et_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_et_tns_2"/>
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_et_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_et_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_et_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_et_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_et_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_et_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_et_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_et_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_et_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_et_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_et_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_et_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_et_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_et_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- ET Despatches -->
                                                      <!-- NGP Despatches -->
                                                      <tr>
                                                            <!-- SECR Hidden -->
                                                            <td rowspan="4" class="text-center">
                                                                  SECR
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="dsph_secr_ngp"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_secr_ngp" value="SECR" hidden />
                                                            </td>
                                                            <!-- SECR Hidden -->
                                                            <!-- NGP Hidden -->
                                                            <td class="text-center">
                                                                  NGP
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="dsph_ngp"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_ngp" value="NGP" hidden />
                                                            </td>
                                                            <!-- NGP Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_ngp_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_ngp_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_ngp_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_ngp_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_ngp_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_ngp_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_ngp_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_ngp_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_ngp_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_ngp_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_ngp_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_ngp_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_ngp_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_ngp_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_ngp_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_ngp_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- NGP Despatches -->
                                                      <!-- GCC Despatches -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SECR Hidden -->
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="dsph_secr_gcc"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_secr_gcc" value="SECR" hidden />
                                                                  <!-- SECR Hidden -->
                                                                  GCC
                                                                  <!-- GCC Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_gcc"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_gcc" value="GCC" hidden />
                                                                  <!-- GCC Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_gcc_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_gcc_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_gcc_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_gcc_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_gcc_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_gcc_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_gcc_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_gcc_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_gcc_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_gcc_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_gcc_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="
                                                                  dsph_gcc_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_gcc_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_gcc_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_gcc_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_gcc_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- GCC Despatches -->
                                                      <!-- CWA Despatches -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SECR Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_secr_cwa"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_secr_cwa" value="SECR" hidden />
                                                                  <!-- SECR Hidden -->
                                                                  CWA
                                                                  <!-- CWA Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_cwa"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_cwa" value="CWA" hidden />
                                                                  <!-- CWA Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_cwa_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_cwa_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_cwa_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_cwa_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_cwa_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_cwa_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_cwa_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_cwa_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_cwa_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_cwa_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_cwa_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_cwa_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_cwa_ldd" />
                                                            </td>    
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_cwa_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_cwa_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_cwa_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- CWA Despatches -->
                                                      <!-- CAF Despatches -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SECR Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_secr_caf"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_secr_caf" value="SECR" hidden />
                                                                  <!-- SECR Hidden -->
                                                                  CAF
                                                                  <!-- CAF Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_caf"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_caf" value="CAF" hidden />
                                                                  <!-- CAF Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_caf_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_caf_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_caf_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_caf_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_caf_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_caf_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_caf_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_caf_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_caf_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_caf_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_caf_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_caf_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_caf_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_caf_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_caf_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_caf_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- CAF Despatches -->
                                                      <!-- BPQ Despatches -->
                                                      <tr>
                                                            <!-- SCR Hidden -->
                                                            <td rowspan="2" class="text-center">
                                                                  SCR
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_scr_bpq"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_scr_bpq" value="SCR" hidden />
                                                            </td>
                                                            <!-- SCR Hidden -->
                                                            <!-- BPQ Hidden -->
                                                            <td class="text-center">
                                                                  BPQ
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_bpq"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_bpq" value="BPQ" hidden />
                                                            </td>
                                                            <!-- BPQ Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_bpq_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_bpq_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_bpq_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_bpq_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_bpq_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_bpq_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_bpq_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_bpq_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_bpq_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_bpq_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_bpq_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_bpq_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_bpq_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_bpq_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_bpq_mt" />
                                                            </td>    
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_bpq_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- BPQ Despatches -->
                                                      <!-- PMKT Despatches -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- SCR Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_scr_pmkt"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_scr_pmkt" value="SCR" hidden />
                                                                  <!-- SCR Hidden -->
                                                                  <!-- PMKT Hidden -->
                                                                  PMKT
                                                                   <cms:hide>
                                                                      <cms:input type='bound' name="dsph_pmkt"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_pmkt" value="PMKT" hidden />
                                                                  <!-- PMKT Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_pmkt_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_pmkt_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_pmkt_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_pmkt_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_pmkt_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_pmkt_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_pmkt_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_pmkt_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_pmkt_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_pmkt_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_pmkt_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_pmkt_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_pmkt_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_pmkt_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_pmkt_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_pmkt_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- PMKT Despatches -->
                                                      <!-- BD Despatches -->
                                                      <tr>
                                                            <!-- BSL Hidden -->
                                                            <td class="text-center" rowspan="2">
                                                                  BSL
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_bsl_bd"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_bsl_bd" value="BSL" hidden />
                                                            </td>
                                                            <!-- BSL Hidden -->
                                                            <!-- BD Hidden -->
                                                            <td class="text-center">
                                                                  BD
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_bd"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_bd" value="BD" hidden />
                                                            </td>
                                                            <!-- BD Hidden -->
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_bd_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_bd_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_bd_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_bd_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_bd_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_bd_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_bd_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_bd_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_bd_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_bd_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_bd_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_bd_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_bd_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_bd_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_bd_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_bd_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- BD Despatches -->
                                                      <!-- CNDB Despatches -->
                                                      <tr>
                                                            <td class="text-center">
                                                                  <!-- BSL Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_bsl_cndb"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_bsl_cndb" value="BSL" hidden />
                                                                  <!-- BSL Hidden -->
                                                                  CNDB
                                                                  <!-- CNDB Hidden -->
                                                                  <cms:hide>
                                                                      <cms:input type='bound' name="dsph_cndb"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_dsph_cndb" value="CNDB" hidden />
                                                                  <!-- CNDB Hidden -->
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-1" name="dsph_fc_cndb_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-2" name="dsph_fc_cndb_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-wgns" name="dsph_cndb_wgns" />
                                                            </td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-3" name="dsph_actual_cndb_tns_1" />
                                                            </td>
                                                            <td width="1%" class="text-center">=</td>
                                                            <td width="3%">
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-tr-4" name="dsph_actual_cndb_tns_2" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-cog" name="dsph_cndb_cog" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ta" name="dsph_cndb_ta" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-la" name="dsph_cndb_la" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-d" name="dsph_cndb_d" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-oth" name="dsph_cndb_oth" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ac" name="dsph_cndb_ac" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-dsl" name="dsph_cndb_dsl" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-ldd" name="dsph_cndb_ldd" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-emp" name="dsph_cndb_emp" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text dsph-mt" name="dsph_cndb_mt" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="dsph_cndb_shortfall" />
                                                            </td>
                                                      </tr>
                                                      <!-- CNDB Despatches -->
                                                      <tr style="height: 10px !important;"></tr>
                                                      <!-- TOTAL Despatches -->
                                                      <tr class="highlight">
                                                            <td class="text-center" colspan="2">
                                                                  <strong>Total</strong>
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_tran1_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_tran1_total" placeholder="0" readonly="1" />
                                                            </td>
                                                            <td>
                                                                  =
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_tran2_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_tran2_total" placeholder="0" readonly="1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_wgns_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_wgns_total" placeholder="0" readonly="1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_tran3_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_tran3_total" placeholder="0" readonly="1" />
                                                            </td>
                                                            <td>
                                                                  =
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_tran4_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_tran4_total" placeholder="0" readonly="1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_cog_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_cog_total" placeholder="0" readonly="1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_ta_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_ta_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_la_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_la_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_d_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_d_total" placeholder="0" readonly="1"  />
                                                            </td>    
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_oth_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_oth_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_ac_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_dsl_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_dsl_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_ldd_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_ldd_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_emp_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_emp_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' id="dsph_mt_total" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="dsph_mt_total" placeholder="0" readonly="1"  />
                                                            </td>
                                                            <td>
                                                                  <input type='text' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" name="" placeholder="0" readonly="1"  />
                                                            </td>
                                                      </tr>
                                                      <!-- TOTAL Despatches -->
                                                </table> 
                                          </div>
                                          <div class="gxcpl-ptop-10"></div>
                                          <!-- Despathces -->
                                          <!-- Ineffective & Surplus -->
                                          <div class="gxcpl-card-body gxcpl-padding-10">
                                                <div class="row">
                                                      <div class="col-md-1 text-center">
                                                            <label>Ineffective</label>
                                                      </div>
                                                      <div class="col-md-5 text-center">
                                                            <cms:input name="ineffective" type="bound" class="gxcpl-input-text" />
                                                            <div class="gxcpl-ptop-10"></div>
                                                      </div>
                                                      <div class="col-md-1 text-center">
                                                            <label>Surplus</label>
                                                            <div class="gxcpl-ptop-10"></div>
                                                      </div>
                                                      <div class="col-md-5 text-center">
                                                            <cms:input name="surplus" type="bound" class="gxcpl-input-text" />
                                                            <div class="gxcpl-ptop-10"></div>
                                                      </div>
                                                </div>
                                          </div>
                                          <!-- Ineffective & Surplus -->
                                          <!-- Body -->
                                    </div>
                                    <!-- Card -->
                              </div>
                              <!-- Mid-Night Position -->
                        </div>
                  </cms:if>

                  <cms:if k_current_step='2' >
                        <!-- AC/DSL Holding -->
                        <div class="col-md-6">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="gxcpl-card">
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>AC/DSL Holding</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr>
                                                                        <td>&nbsp;</td>
                                                                        <td class="text-center gxcpl-fw-700">AC</td>
                                                                        <td class="text-center gxcpl-fw-700">DSL</td>
                                                                        <td class="text-center gxcpl-fw-700" colspan="3">L/Eng.</td>
                                                                  </tr>
                                                                  <tr class="gxcpl-fw-700">
                                                                        <td width="20%">
                                                                              Holding
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="dsl_hld_holding"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_dsl_hld_holding" value="Holding" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_ac_vlu" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_dsl_vlu" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_leng_vlu1" />
                                                                        </td>
                                                                        <td width="4%" class="text-center">=</td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_leng_vlu2" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr class="gxcpl-fw-700">
                                                                        <td width="20%">
                                                                              Kms
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="dsl_hld_kms"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_dsl_hld_kms" value="Kms" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="kms_ac_vlu" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="kms_dsl_vlu" />
                                                                        </td>
                                                                        <td colspan="3">
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="kms_l_eng_vlu" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>Inter Rly Outage</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>&nbsp;</td>
                                                                        <td>AC</td>
                                                                        <td>MU</td> 
                                                                  </tr>
                                                                  <tr>
                                                                        <td width="30%" class="gxcpl-fw-700">
                                                                              CR on SC
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="cr_sc"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_cr_sc" value="CR on SC" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="cr_sc_ac" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="cr_sc_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              SC on CR
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="sc_cr"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_sc_cr" value="SC on CR" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="sc_cr_ac" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="sc_cr_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              SE on CR
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="se_cr"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_se_cr" value="SE on CR" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="se_cr_ac" />
                                                                        </td> 
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="se_cr_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              CR on SE
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="cr_se"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_cr_se" value="CR on SE" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="cr_se_ac" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="cr_se_mu" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                          </div>
                                          <div class="gxcpl-ptop-10"></div>
                                    </div>
                              </div>
                        </div>
                        <!-- AC/DSL Holding -->
                        <div class="col-md-6">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="gxcpl-card">
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>Holding</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700">
                                                                        <td width="30%">Holding</td>
                                                                        <td class="text-center">00 hr</td>
                                                                        <td class="text-center">MU</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Net
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_net"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_net" value="Net" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_net_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_net_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Sdg
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_sdg"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_sdg" value="Sdg" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_sdg_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_sdg_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              B/E
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_be"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_be" value="B/E" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_be_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_be_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              LA
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_la"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_la" value="LA" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_la_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_la_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              TA
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_ta"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_ta" value="TA" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_ta_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_ta_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Dead
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_dead"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_dead" value="Dead" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_dead_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_dead_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Cog
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_cog"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_cog" value="Cog" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_cog_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_cog_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Deptl
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_deptl"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_deptl" value="Deptl" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_deptl_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <input type='bound' class="gxcpl-input-text" name="hld_deptl_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              ELS
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_els"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_els" value="ELS" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_els_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_els_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              T/S
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_ts"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_ts" value="T/S" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_ts_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_ts_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              AC/MU
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_acmu"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_acmu" value="AC/MU" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_acmu_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_acmu_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              DSL
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_dsl"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_dsl" value="DSL" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_dsl_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_dsl_mu" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              MU
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="hld_mu"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_hld_mu" value="MU" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_mu_hr" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="hld_mu_mu" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-10"></div>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                              <div class="gxcpl-ptop-20"></div>
                        </div>            
                  </cms:if>   
                  
                  <cms:if k_current_step='3' >
                        <!-- Punctuality -->
                        <div class="col-md-8 col-md-offset-2">
                              <!-- Card -->
                              <div class="gxcpl-card">
                                    <!-- Body -->
                                    <div class="gxcpl-card-body">
                                          <div class="gxcpl-padding-10">
                                                <h4 class="gxcpl-padding-10">PUNCTUALITY</h4>
                                                <div class="gxcpl-ptop-10"></div>
                                                <table class="gxcpl-table" width="100%" >
                                                      <tr class="gxcpl-fw-700 text-center">
                                                            <td>&nbsp;</td>
                                                            <td >Run</td>
                                                            <td>Lost</td>
                                                            <td>Train nos.</td>
                                                      </tr>
                                                      <tr>
                                                            <td width="20%" class="gxcpl-fw-700">
                                                                  M/Exp
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="mexp_punc1"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_mexp_punc1" value="M/Exp" hidden />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="mexp_run_punc1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="mexp_lost_punc1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="mexp_trno_punc1" />
                                                            </td>
                                                      </tr>
                                                      <tr>
                                                            <td class="gxcpl-fw-700">
                                                                  Pass.
                                                                  <cms:hide>
                                                                        <cms:input type='bound' name="pass_punc1"/>
                                                                  </cms:hide>
                                                                  <input type='text' name="f_pass_punc1" value="Pass" hidden />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="pass_run_punc1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="pass_lost_punc1" />
                                                            </td>
                                                            <td>
                                                                  <cms:input type='bound' class="gxcpl-input-text" name="pass_trno_punc1" />
                                                            </td>
                                                      </tr>
                                                </table>
                                                <div class="gxcpl-ptop-20"></div>
                                          </div>
                                    </div>
                                    <!-- Body -->
                              </div>
                              <!-- Card -->
                              <div class="gxcpl-ptop-20"></div>
                        </div>
                        <!-- Puncuality -->
                  </cms:if> 

                  <cms:if k_current_step='4' >
                        <!-- Puncuality1 -->
                        <div class="col-md-6">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="gxcpl-card">
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>PUNCTUALITY</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>&nbsp;</td>
                                                                        <td>Run</td>
                                                                        <td>Lost</td>
                                                                        <td>Train nos.</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td width="25%" class="gxcpl-fw-700">
                                                                              M/Exp
                                                                              <cms:hide>
                                                            <cms:input type='bound' name="mexp_punc2"/>
                                                        </cms:hide>
                                                        <input type='text' name="f_mexp_punc2" value="M/Exp" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="mexp_run_punc2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="mexp_lost_punc2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="mexp_trno_punc2" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Pass.
                                                                              <cms:hide>
                                                            <cms:input type='bound' name="pass_punc2"/>
                                                        </cms:hide>
                                                        <input type='text' name="f_pass_punc2" value="Pass" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="pass_run_punc2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="pass_lost_punc2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="pass_trno_punc2" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>STOCK HOLDING</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td rowspan="2">&nbsp;</td>
                                                                        <td colspan="2">BOXN</td>
                                                                        <td colspan="2">OT</td>
                                                                        <td colspan="2">Jumbo</td>
                                                                        <td colspan="2">Steel</td>
                                                                        <td colspan="2">Cont</td>
                                                                  </tr>
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <!-- <td>&nbsp;</td> -->
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td width="15%" class="gxcpl-fw-700">
                                                                              Recd
                                                                              <cms:hide>
                                                            <cms:input type='bound' name="recd_stck1"/>
                                                        </cms:hide>
                                                        <input type='text' name="f_recd_stck1" value="Recd" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_boxn1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_boxn1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_ot1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_ot1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_jumbo1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_jumbo1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_steel1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_steel1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_cont1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_cont1" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Desp
                                                                              <cms:hide>
                                                            <cms:input type='bound' name="desp_stck1"/>
                                                        </cms:hide>
                                                        <input type='text' name="f_desp_stck1" value="Desp" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_boxn1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_boxn1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_ot1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_ot1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_jumbo1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_jumbo1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_steel1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_steel1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_cont1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_cont1" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                          </div>
                                          <div class="gxcpl-ptop-10"></div>
                                    </div>
                              </div>
                        </div>
                        <!-- Puncuality1 -->
                        <div class="col-md-6">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="gxcpl-card">
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>Loading</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>&nbsp;</td>
                                                                        <td colspan="2">Forecast</td>
                                                                        <td colspan="2">Loading</td>
                                                                        <td rowspan="2">Rejection</td>
                                                                        <td rowspan="2">Todays' Forecast</td>
                                                                  </tr>
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>&nbsp;</td>
                                                                        <td>Rakes</td>
                                                                        <td>Wagons</td>
                                                                        <td>Rakes</td>
                                                                        <td>Wagons</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td width="20%" class="gxcpl-fw-700">
                                                                              Coal
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="coal"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_coal" value="Coal" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text fc_rake" name="coal_fc_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text fc_wgns" name="coal_fc_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text ld_rake" name="coal_ld_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text ld_wgns" name="coal_ld_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text rejct" name="coal_rejc" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text tdays_fc" name="coal_tdays_fc" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Cement
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="cement"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_cement" value="Cement" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text fc_rake" name="cement_fc_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text fc_wgns" name="cement_fc_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text ld_rake" name="cement_ld_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text ld_wgns" name="cement_ld_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text rejct" name="cement_rejc" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text tdays_fc" name="cement_tdays_fc" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Others
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="others"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_others" value="Others" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text fc_rake" name="others_fc_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text fc_wgns" name="others_fc_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text ld_rake" name="others_ld_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text ld_wgns" name="others_ld_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text rejct" name="others_rejc" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text tdays_fc" name="others_tdays_fc" />
                                                                        </td>
                                                                  </tr>
                                                                   <tr class="highlight">
                                                                        <td>
                                                                              <strong>Total</strong>
                                                                        </td>
                                                                        <td>
                                                                              <cms:input id="total_fc_rake" name="total_fc_rake" class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" type="bound" placeholder="0" readonly='1' />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" id="total_fc_wgn" placeholder="0" readonly='1' name="total_fc_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" id="total_ld_rake" placeholder="0" readonly='1' name="total_ld_rake" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" id="total_ld_wgn" placeholder="0" readonly='1' name="total_ld_wgn" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" id="total_rejc" placeholder="0" readonly='1' name="total_rejc" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text gxcpl-disabled gxcpl-fw-700" id="total_tdays_fc" placeholder="0" readonly='1' name="total_tdays_fc" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>DIST WAGONS</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>Available</td>
                                                                        <td>Placed</td>
                                                                        <td>Unldd.</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="avai_wgns1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="plce_wgns1" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="unld_wgns1" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                              <div class="gxcpl-ptop-50"></div>
                        </div>
                  </cms:if> 

                  <cms:if k_current_step='5' >
                        <div class="col-md-6">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="gxcpl-card">
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>PUNCTUALITY</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>&nbsp;</td>
                                                                        <td>Run</td>
                                                                        <td>Lost</td>
                                                                        <td>Train nos.</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td width="25%" class="gxcpl-fw-700">
                                                                              M/Exp
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="mexp_punc3"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_mexp_punc3" value="M/Exp" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="mexp_run_punc3" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="mexp_lost_punc3" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="mexp_trno_punc3" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Pass.
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="pass_punc3"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_pass_punc3" value="Pass" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="pass_run_punc3" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="pass_lost_punc3" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="pass_trno_punc3" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>DIST WAGONS</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table" width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td>Available</td>
                                                                        <td>Placed</td>
                                                                        <td>Unldd.</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="avai_wgns2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="plce_wgns2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="unld_wgns2" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>
                                          </div>
                                          <div class="gxcpl-ptop-20"></div>
                                    </div>
                              </div>
                        </div>
                        <div class="col-md-6">
                              <div class="row">
                                    <div class="col-md-12">
                                          <div class="gxcpl-card">
                                                <div class="gxcpl-card-body">
                                                      <div class="gxcpl-padding-10">
                                                            <h4>STOCK HOLDING</h4>
                                                            <div class="gxcpl-ptop-10"></div>
                                                            <table class="gxcpl-table"  width="100%">
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <td rowspan="2">&nbsp;</td>
                                                                        <td colspan="2">BOXN</td>
                                                                        <td colspan="2">OT</td>
                                                                        <td colspan="2">Jumbo</td>
                                                                        <td colspan="2">Steel</td>
                                                                        <td colspan="2">Cont</td>
                                                                  </tr>
                                                                  <tr class="gxcpl-fw-700 text-center">
                                                                        <!-- <td>&nbsp;</td> -->
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                        <td>Ldd</td>
                                                                        <td>Emp</td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td width="15%" class="gxcpl-fw-700">
                                                                              Recd
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="recd_stck2"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_recd_stck2" value="Recd" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_boxn2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_boxn2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_ot2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_ot2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_jumbo2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_jumbo2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_steel2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_steel2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_ldd_cont2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="recd_emp_cont2" />
                                                                        </td>
                                                                  </tr>
                                                                  <tr>
                                                                        <td class="gxcpl-fw-700">
                                                                              Desp
                                                                              <cms:hide>
                                                                                    <cms:input type='bound' name="desp_stck2"/>
                                                                              </cms:hide>
                                                                              <input type='text' name="f_desp_stck2" value="Desp" hidden />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_boxn2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_boxn2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_ot2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_ot2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_jumbo2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_jumbo2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_steel2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_steel2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_ldd_cont2" />
                                                                        </td>
                                                                        <td>
                                                                              <cms:input type='bound' class="gxcpl-input-text" name="desp_emp_cont2" />
                                                                        </td>
                                                                  </tr>
                                                            </table>
                                                            <div class="gxcpl-ptop-20"></div>
                                                      </div>
                                                </div>            
                                          </div>
                                    </div>
                              </div>
                              <div class="gxcpl-ptop-50"></div>
                        </div>
                  </cms:if> 
                  
                <div class="gxcpl-ptop-20"></div>
                <center class="nav">
                    <cms:if k_current_step gt '1'>
                        <button type="submit" class="btn btn-success btn-sm" name="back" >
                           <i class="fa fa-chevron-circle-left" aria-hidden="true"></i> BACK
                        </button>
                    </cms:if>
                    <button type="submit" name="next" class="btn btn-primary btn-sm" >
                        <cms:if k_current_step=total_pages>
                            <i class="fa fa-floppy-o" aria-hidden="true"></i> SAVE<cms:else />
                            NEXT <i class="fa fa-chevron-circle-right" aria-hidden="true"></i> 
                        </cms:if>
                    </button>
                </center>
                <div class="gxcpl-ptop-20"></div>

                </cms:if>

            </cms:form>
        <!-- </div> -->
    </div>
    <!-- Content Here -->
<cms:embed 'footer.html' />

<?php COUCH::invoke(); ?>