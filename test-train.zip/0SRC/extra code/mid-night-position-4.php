<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Midnight Position-4" clonable="1" routable='1' parent='_mdpt_' order='4'>
	<!-- DATE on Every page -->
    <cms:editable name="mdp_date" label="Mid-Night Position Date" type="datetime" allow_time='0' required="1" format="Y-m-d" order="1" />
   	<!-- DATE on Every page -->

   	<!-- PUNCTUALITY  -->
   	<cms:editable name="punctuation1" label='Punctuality' type="group" order="2" >
	   	<cms:editable name="punc_row" label="Punctuality" type="row" order="2">
	   		<cms:editable name="mexp_punc2" label="M/Exp Punctuality" type="text" order="2" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="mexp_run_punc2" label="M/Exp Run" type="text" order="3" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="mexp_lost_punc2" label="M/Exp Lost" type="text" order="4" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="mexp_trno_punc2" label="M/Exp Train Number" type="text" order="5" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="pass_punc2" label="Pass Punctuality" type="text" order="6" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="pass_run_punc2" label="Pass Run" type="text" order="7" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="pass_lost_punc2" label="Pass Lost" type="text" order="8" group="punctuation1" class="col-md-3" />
	   		<cms:editable name="pass_trno_punc2" label="Pass Train Number" type="text" order="9" group="punctuation1" class="col-md-3" />
	   	</cms:editable>
   	</cms:editable>
   	<!-- PUNCTUALITY  -->

   	<!-- STOCK HOLDING -->
   	<cms:editable name="stck_hld1" label="Stock Holding" type="group" order="3" >
	   	<cms:editable name="stck_row" type="row">
	   		<cms:editable name="recd_stck1" label="Recd Stock Holding" type="text" group="stck_hld1" order="1" class="col-md-2" />
	   		<cms:editable name="recd_ldd_boxn1" label="Recd Ldd BOXN" type="text" group="stck_hld1" order="2" class="col-md-2" />
	   		<cms:editable name="recd_emp_boxn1" label="Recd Emp BOXN" type="text" group="stck_hld1" order="3" class="col-md-2" />
	   		<cms:editable name="recd_ldd_ot1" label="Recd Ldd OT" type="text" group="stck_hld1" order="4" class="col-md-2" />
	   		<cms:editable name="recd_emp_ot1" label="Recd Emp OT" type="text" group="stck_hld1" order="5" class="col-md-2" />
	   		<cms:editable name="recd_ldd_jumbo1" label="Recd Ldd Jumbo" type="text" group="stck_hld1" order="6" class="col-md-2" />
	   		<cms:editable name="recd_emp_jumbo1" label="Recd Emp Jumbo" type="text" group="stck_hld1" order="7" class="col-md-2" />
	   		<cms:editable name="recd_ldd_steel1" label="Recd Ldd Steel" type="text" group="stck_hld1" order="8" class="col-md-2" />
	   		<cms:editable name="recd_emp_steel1" label="Recd Emp Steel" type="text" group="stck_hld1" order="9" class="col-md-2" />
	   		<cms:editable name="recd_ldd_cont1" label="Recd Ldd Cont" type="text" group="stck_hld1" order="10" class="col-md-2" />
	   		<cms:editable name="recd_emp_cont1" label="Recd Emp Cont" type="text" group="stck_hld1" order="11" class="col-md-2" />

	   		<cms:editable name="desp_stck1" label="Desp Stock Holding" type="text" group="stck_hld1" order="12" class="col-md-2" />
	   		<cms:editable name="desp_ldd_boxn1" label="Desp Ldd BOXN" type="text" group="stck_hld1" order="13" class="col-md-2" />
	   		<cms:editable name="desp_emp_boxn1" label="Desp Emp BOXN" type="text" group="stck_hld1" order="14" class="col-md-2" />
	   		<cms:editable name="desp_ldd_ot1" label="Desp Ldd OT" type="text" group="stck_hld1" order="15" class="col-md-2" />
	   		<cms:editable name="desp_emp_ot1" label="Desp Emp OT" type="text" group="stck_hld1" order="16" class="col-md-2" />
	   		<cms:editable name="desp_ldd_jumbo1" label="Desp Ldd Jumbo" type="text" group="stck_hld1" order="17" class="col-md-2" />
	   		<cms:editable name="desp_emp_jumbo1" label="Desp Emp Jumbo" type="text" group="stck_hld1" order="18" class="col-md-2" />
	   		<cms:editable name="desp_ldd_steel1" label="Desp Ldd Steel" type="text" group="stck_hld1" order="19" class="col-md-2" />
	   		<cms:editable name="desp_emp_steel1" label="Desp Emp Steel" type="text" group="stck_hld1" order="20" class="col-md-2" />
	   		<cms:editable name="desp_ldd_cont1" label="Desp Ldd Cont" type="text" group="stck_hld1" order="21" class="col-md-2" />
	   		<cms:editable name="desp_emp_cont1" label="Desp Emp Cont" type="text" group="stck_hld1" order="22" class="col-md-2" />
	   	</cms:editable>
   	</cms:editable>
   	<!-- STOCK HOLDING -->
   	<!-- Loading -->
   	<cms:editable name="loading" label="Loading" type="group" order="4" >
	   	<cms:editable name="lding_row" type="row" >
	   		<cms:editable name="coal" label="Coal" type="text" group="loading" order="1" class="col-md-3" />
	   		<cms:editable name="coal_fc_rake" label="Coal Forecasted Rakes" type="text" group="loading" order="2" class="col-md-3" />
	   		<cms:editable name="coal_fc_wgn" label="Coal Forecasted Wagons" type="text" group="loading" order="3" class="col-md-3" />
	   		<cms:editable name="coal_ld_rake" label="Coal Loading Rakes" type="text" group="loading" order="4" class="col-md-3" />
	   		<cms:editable name="coal_ld_wgn" label="Coal Loading Wagons" type="text" group="loading" order="5" class="col-md-3" />
	   		<cms:editable name="coal_rejc" label="Coal Rejection" type="text" group="loading" order="6" class="col-md-3" />
	   		<cms:editable name="coal_tdays_fc" label="Coal Todays Forecast" type="text" group="loading" order="7" class="col-md-3" />

	   		<cms:editable name="cement" label="Cement" type="text" group="loading" order="8" class="col-md-3" />
	   		<cms:editable name="cement_fc_rake" label="Cement Forecasted Rakes" type="text" group="loading" order="9" class="col-md-3" />
	   		<cms:editable name="cement_fc_wgn" label="Cement Forecasted Wagons" type="text" group="loading" order="10" class="col-md-3" />
	   		<cms:editable name="cement_ld_rake" label="Cement Loading Rakes" type="text" group="loading" order="11" class="col-md-3" />
	   		<cms:editable name="cement_ld_wgn" label="Cement Loading Wagons" type="text" group="loading" order="12" class="col-md-3" />
	   		<cms:editable name="cement_rejc" label="Cement Rejection" type="text" group="loading" order="13" class="col-md-3" />
	   		<cms:editable name="cement_tdays_fc" label="Cement Todays Forecast" type="text" group="loading" order="14" class="col-md-3" />

	   		<cms:editable name="others" label="Others" type="text" group="loading" order="15" class="col-md-3" />
	   		<cms:editable name="others_fc_rake" label="Others Forecasted Rakes" type="text" group="loading" order="16" class="col-md-3" />
	   		<cms:editable name="others_fc_wgn" label="Others Forecasted Wagons" type="text" group="loading" order="17" class="col-md-3" />
	   		<cms:editable name="others_ld_rake" label="Others Loading Rakes" type="text" group="loading" order="18" class="col-md-3" />
	   		<cms:editable name="others_ld_wgn" label="Others Loading Wagons" type="text" group="loading" order="19" class="col-md-3" />
	   		<cms:editable name="others_rejc" label="Others Rejection" type="text" group="loading" order="20" class="col-md-3" />
	   		<cms:editable name="others_tdays_fc" label="Others Todays Forecast" type="text" group="loading" order="21" class="col-md-3" />

	   		<cms:editable name="total_fc_rake" label="Total Forecasted Rakes" type="text" group="loading" order="22" class="col-md-3" />
	   		<cms:editable name="total_fc_wgn" label="Total Forecasted Wagons" type="text" group="loading" order="23" class="col-md-3" />
	   		<cms:editable name="total_ld_rake" label="Total Loading Rakes" type="text" group="loading" order="24" class="col-md-3" />
	   		<cms:editable name="total_ld_wgn" label="Total Loading Wagons" type="text" group="loading" order="25" class="col-md-3" />
	   		<cms:editable name="total_rejc" label="Total Rejection" type="text" group="loading" order="26" class="col-md-3" />
	   		<cms:editable name="total_tdays_fc" label="Total Todays Forecast" type="text" group="loading" order="27" class="col-md-3" />
	   	</cms:editable>
   	</cms:editable>
   	<!-- Loading -->
   	<!-- DIST WAGONS -->
   	<cms:editable name="dist_wgns1" label="Dist Wagons" type="group" order="5" >
	   	<cms:editable name="wgns_row" type="row">
	   		<cms:editable name="avai_wgns1" label="Available" type="text" group="dist_wgns1" order="1" class="col-md-4" />
	   		<cms:editable name="plce_wgns1" label="Placed" type="text" group="dist_wgns1" order="2" class="col-md-4" />
	   		<cms:editable name="unld_wgns1" label="Unldd" type="text" group="dist_wgns1" order="3" class="col-md-4" />
	   	</cms:editable>
   	</cms:editable>
   	<!-- DIST WAGONS -->
   	<!-- Custom Routes -->
	<cms:route name='list_mnp4' path='' />
	<cms:route name='create_mnp4' path='create' />
	<cms:route name='edit_mnp4' path='{:id}/edit' >
	    <cms:route_validators id='non_zero_integer' />
	</cms:route>
	<cms:route name='delete_mnp4' path='{:id}/delete' >
	    <cms:route_validators id='non_zero_integer' />
	</cms:route>
	<!-- Custom Routes -->
</cms:template>
<cms:embed 'header.html' />
	<!-- Content Here -->
	<div class="container-fluid">
	    <div class="row">
			<div class="gxcpl-ptop-30"></div>

			<!-- Section Divider -->
			<div class="gxcpl-ptop-10"></div>
			<!-- <div class="gxcpl-divider-dark"></div> -->
			<div class="gxcpl-ptop-10"></div>
			<!-- Section Divider -->

			<!-- Mid Night Position -->
			<cms:match_route debug='0' />
			<cms:embed "mid-posi-4/<cms:show k_matched_route />.html" />
			<!-- Mid Night Position -->
	    </div>
	</div>
	<!-- Content Here -->			
<cms:embed 'footer.html' />               
<?php COUCH::invoke( K_IGNORE_CONTEXT ); ?>