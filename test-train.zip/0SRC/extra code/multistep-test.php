<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Multi Step Test Form" clonable='1' routable='1' parent='_mdpt_' order='5' >
	<cms:editable name="element_1" label="Element " type="text" order="1" />
	<cms:editable name="element_2" label="Element " type="text" order="2" />
	<cms:editable name="element_3" label="Element " type="text" order="3" />
	<cms:editable name="element_4" label="Element " type="text" order="4" />
	<cms:editable name="element_5" label="Element " type="text" order="5" />
	<cms:editable name="element_6" label="Element " type="text" order="5" />
	<!-- DATE on Every page -->
      <cms:editable name="mdp_date" label="Mid-Night Position Date" type="datetime" allow_time='0' required='1' format="Y-m-d" order="1" />
      <!-- DATE on Every page -->
</cms:template>
<!-- Regular form. Just make sure the method is 'post' -->
<cms:form method='post' anchor='0' >

	<cms:set total_pages = '3' />

	<cms:embed 'multi_form_handler.html' />

	<cms:if k_current_step gt total_pages >
	   	<cms:db_persist 
		  	_masterpage=k_template_name
		  	_mode='create'
		  	_invalidate_cache='0'
		  	_auto_title='1'
		  	mdp_date  = frm_mdp_date
		  	element_1 = frm_element_1
		  	element_2 = frm_element_2
		  	element_3 = frm_element_3
		  	element_4 = frm_element_4
		  	element_5 = frm_element_5
		  	element_6 = frm_element_6
	  	>
		  	<cms:if k_success>
		  		<cms:set my_page_id="<cms:show k_last_inserted_id />" scope="global" />
		  	</cms:if>

		  	<cms:if k_error >
		        <div class="row">
		            <cms:each k_error >
		                <div class="col-md-4">
		                    <div class="alert alert-danger">
		                        <cms:show item />
		                    </div>
		                </div>
		            </cms:each>
		        </div>
			</cms:if>
	  	</cms:db_persist> 
	  	DONE!!
	<cms:else />
      	<div class="row">
            <div class="col-md-12">
              	<div class="gxcpl-card">
                    <div class="gxcpl-card-header">
                        <h5>
                            Operating Performance of Date : 
                            <cms:hide>
                                <cms:input type='datetime' name="mdp_date" />
                            </cms:hide>
                            <input type='date' name="mdp_date" class="gxcpl-input-text" value="<cms:date return='yesterday' format='Y-m-d' />" style="width:auto;" />
                        </h5>
                    </div>
              	</div>
            </div>
      	</div>
		<cms:if k_current_step='1' >
			<fieldset>
				<legend>Page One (1 of 3)</legend>
				<p>
					<label for='element_1'>Element 1:</label><cms:input type='text' name='element_1' required='1' /> (required)
					<cms:if k_error_element_1 ><span style="color:red"><cms:show k_error_element_1 /></span></cms:if>
				</p>
				<p>
					<label for='element_2'>Element 2:</label><cms:input type='text' name='element_2' />
				</p>
			</fieldset>
		</cms:if>

		<cms:if k_current_step='2' >

			<fieldset>
				<legend>Page Two (2 of 3)</legend>
				<p>	
					<label for='element_3'>Element 3:</label><cms:input type='text' name='element_3' />
				</p>
				<p>
					<label for='element_4'>Element 4:</label><cms:input type='text' name='element_4' required='1' /> (required)
					<cms:if k_error_element_4 ><span style="color:red"><cms:show k_error_element_4 /></span></cms:if>
				</p>
			</fieldset>
		</cms:if>
			
		<cms:if k_current_step='3' >
			<fieldset>
				<legend>Page Three (3 of 3)</legend>
				<p>
					<label for='element_5'>Element 5:</label><cms:input type='text' name='element_5' />
				</p>
				<p>
					<label for='element_6'>Element 6:</label><cms:input type='text' name='element_6'/>
				</p>
			</fieldset>
			
		</cms:if>
		
		<cms:if k_current_step='1' >
			Step1
		</cms:if>

		<cms:if k_current_step='2' >
			Step2
		</cms:if>   

		<cms:if k_current_step='3' >
			Step3
		</cms:if> 

		<p class="nav">
		<cms:if k_current_step gt '1'><input type="submit" name="back" value="Previous"></cms:if>
		<input type="submit" name="next" value="<cms:if k_current_step=total_pages>Finish<cms:else />Next</cms:if>">
		</p>

	</cms:if>

</cms:form>

<?php COUCH::invoke(); ?>