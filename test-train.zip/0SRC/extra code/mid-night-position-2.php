<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Midnight Position-2" clonable="1" routable='1' parent='_mdpt_' order='2'>
	<!-- DATE on Every page -->
    <cms:editable name="mdp_date" label="Mid-Night Position Date" type="datetime" allow_time='0' required="1" format="Y-m-d" order="1" />
    <!-- DATE on Every page -->
    <!-- AC/DSL Holding -->
    <cms:editable name="dsl_holding" label="DSL Holding" type="group" order="2">
	    <cms:editable name="dsl_holding_row" type="row">
	    	<cms:editable name="dsl_hld_holding" label="DSL Holding" type="text" group="dsl_holding" order="1" class="col-md-2" />
	    	<cms:editable name="hld_ac_vlu" label="Holding AC Value" type="text" group="dsl_holding" order="2" class="col-md-2" />
	    	<cms:editable name="hld_dsl_vlu" label="Holding DSL Value" type="text" group="dsl_holding" order="3"  class="col-md-2" />
	    	<cms:editable name="hld_leng_vlu1" label="Holding L/Eng Value1" type="text" group="dsl_holding" order="4" class="col-md-2" />
	    	<cms:editable name="hld_leng_vlu2" label="Holding L/Eng Value2" type="text" group="dsl_holding" order="5" class="col-md-3" />
	    	<cms:editable name="dsl_hld_kms" label="DSL Holding Kms" type="text" group="dsl_holding" order="6" class="col-md-2" />
	    	<cms:editable name="kms_ac_vlu" label="Kms AC Value" type="text" group="dsl_holding" order="7" class="col-md-2" />
	    	<cms:editable name="kms_dsl_vlu" label="Kms DSL Value" type="text" group="dsl_holding" order="8" class="col-md-2" />
	    	<cms:editable name="kms_l_eng_vlu" label="Kms L/Eng Value" type="text" group="dsl_holding" order="9" class="col-md-2" />
	    </cms:editable>
    </cms:editable>
    <!-- AC/DSL Holding -->

    <!-- Inter Rly Outage -->
    <cms:editable name="intr_rly" label="Inter Rly Outage" type="group" order="3">
    	<cms:editable name="intr_rly_row" type="row">
        	<cms:editable name="cr_sc" label="CR on SC" type="text" group="" order="1" class="col-md-2" />
        	<cms:editable name="sc_cr" label="SC on CR" type="text" group="" order="2" class="col-md-2" />
        	<cms:editable name="se_cr" label="SE on CR" type="text" group="" order="3" class="col-md-2" />
        	<cms:editable name="cr_se" label="CR on SE" type="text" group="" order="4" class="col-md-2" />
        	<cms:editable name="cr_sc_ac" label="CR on SC AC" type="text" group="" order="5" class="col-md-2" />
        	<cms:editable name="cr_sc_mu" label="CR on SC MU" type="text" group="" order="6" class="col-md-2" />
        	<cms:editable name="sc_cr_ac" label="SC on CR AC" type="text" group="" order="7" class="col-md-2" />
        	<cms:editable name="sc_cr_mu" label="SC on CR MU" type="text" group="" order="8" class="col-md-2" />
        	<cms:editable name="se_cr_ac" label="SE on CR AC" type="text" group="" order="9" class="col-md-2" />
        	<cms:editable name="se_cr_mu" label="SE on CR MU" type="text" group="" order="10" class="col-md-2" />
        	<cms:editable name="cr_se_ac" label="CR on SE AC" type="text" group="" order="11" class="col-md-2" />
        	<cms:editable name="cr_se_mu" label="CR on SE MU" type="text" group="" order="12" class="col-md-2" />
        </cms:editable>
    </cms:editable>
	<!-- Inter Rly Outage -->

	<!-- Holding -->
	<cms:editable name="hld" label="Holding" type="group" order="4">
		<cms:editable name="hld_row" type="row">
			<cms:editable name="hld_net" label="Holding Net" type="text" group="holding" order="1" class="col-md-2" />
        	<cms:editable name="hld_net_hr" label="Holding Net 00 hr" type="text" group="hld" order="2" class="col-md-2" />
        	<cms:editable name="hld_net_mu" label="Holding Net MU" type="text" group="hld" order="3" class="col-md-2" />
        	<cms:editable name="hld_sdg" label="Holding Sdg" type="text" group="hld" order="4" class="col-md-2" />
        	<cms:editable name="hld_sdg_hr" label="Holding Sdg 00 hr" type="text" group="hld" order="5" class="col-md-2" />
        	<cms:editable name="hld_sdg_mu" label="Holding Sdg MU" type="text" group="hld" order="6" class="col-md-2" />
        	<cms:editable name="hld_be" label="Holding B/E" type="text" group="hld" order="7" class="col-md-2" />
        	<cms:editable name="hld_be_hr" label="Holding B/E 00 hr" type="text" group="hld" order="8" class="col-md-2" />
        	<cms:editable name="hld_be_mu" label="Holding B/E MU" type="text" group="hld" order="9" class="col-md-2" />
        	<cms:editable name="hld_la" label="Holding LA" type="text" group="hld" order="10" class="col-md-2" />
        	<cms:editable name="hld_la_hr" label="Holding LA 00 hr" type="text" group="hld" order="11" class="col-md-2" />
        	<cms:editable name="hld_la_mu" label="Holding LA MU" type="text" group="hld" order="12" class="col-md-2" />
        	<cms:editable name="hld_ta" label="Holding TA" type="text" group="hld" order="13" class="col-md-2" />
        	<cms:editable name="hld_ta_hr" label="Holding TA 00 hr" type="text" group="hld" order="14" class="col-md-2" />
        	<cms:editable name="hld_ta_mu" label="Holding TA MU" type="text" group="hld" order="15" class="col-md-2" />
        	<cms:editable name="hld_dead" label="Holding Dead" type="text" group="hld" order="16" class="col-md-2" />
        	<cms:editable name="hld_dead_hr" label="Holding Dead 00 hr" type="text" group="hld" order="17" class="col-md-2" />
        	<cms:editable name="hld_dead_mu" label="Holding Dead MU" type="text" group="hld" order="18" class="col-md-2" />
        	<cms:editable name="hld_cog" label="Holding Cog" type="text" group="hld" order="19" class="col-md-2" />
        	<cms:editable name="hld_cog_hr" label="Holding Cog 00 hr" type="text" group="hld" order="20" class="col-md-2" />
        	<cms:editable name="hld_cog_mu" label="Holding Cog MU" type="text" group="hld" order="21" class="col-md-2" />
        	<cms:editable name="hld_deptl" label="Holding Deptl" type="text" group="hld" order="22" class="col-md-2" />
        	<cms:editable name="hld_deptl_hr" label="Holding Deptl 00 hr" type="text" group="hld" order="23" class="col-md-2" />
        	<cms:editable name="hld_deptl_mu" label="Holding Deptl MU" type="text" group="hld" order="24" class="col-md-2" />
        	<cms:editable name="hld_els" label="Holding ELS" type="text" group="hld" order="25" class="col-md-2" />
        	<cms:editable name="hld_els_hr" label="Holding ELS 00 hr" type="text" group="hld" order="26" class="col-md-2" />
        	<cms:editable name="hld_els_mu" label="Holding ELS MU" type="text" group="hld" order="27" class="col-md-2" />
        	<cms:editable name="hld_ts" label="Holding T/S" type="text" group="hld" order="28" class="col-md-2" />
        	<cms:editable name="hld_ts_hr" label="Holding T/S 00 hr" type="text" group="hld" order="29" class="col-md-2" />
        	<cms:editable name="hld_ts_mu" label="Holding T/S MU" type="text" group="hld" order="30" class="col-md-2" />
        	<cms:editable name="hld_acmu" label="Holding AC/MU" type="text" group="hld" order="31" class="col-md-2" />
        	<cms:editable name="hld_acmu_hr" label="Holding AC/MU 00 hr" type="text" group="hld" order="32" class="col-md-2" />
        	<cms:editable name="hld_acmu_mu" label="Holding AC/MU MU" type="text" group="hld" order="33" class="col-md-2" />
        	<cms:editable name="hld_dsl" label="Holding DSL" type="text" group="hld" order="34" class="col-md-2" />
        	<cms:editable name="hld_dsl_hr" label="Holding DSL 00 hr" type="text" group="hld" order="35" class="col-md-2" />
        	<cms:editable name="hld_dsl_mu" label="Holding DSL MU" type="text" group="hld" order="36" class="col-md-2" />
        	<cms:editable name="hld_mu" label="Holding MU" type="text" group="hld" order="37" class="col-md-2" />
        	<cms:editable name="hld_mu_hr" label="Holding MU 00 hr" type="text" group="hld" order="38" class="col-md-2" />
        	<cms:editable name="hld_mu_mu" label="Holding MU MU" type="text" group="hld" order="39" class="col-md-2" />
        </cms:editable>
    </cms:editable>
	<!-- Holding -->

	<!-- Custom Routes -->
	<cms:route name='list_mnp2' path='' />
	<cms:route name='create_mnp2' path='create' />
	<cms:route name='edit_mnp2' path='{:id}/edit' >
		<cms:route_validators id='non_zero_integer' />
	</cms:route>
	<cms:route name='delete_mnp2' path='{:id}/delete' >
		<cms:route_validators id='non_zero_integer' />
	</cms:route>
	<!-- Custom Routes -->

</cms:template>
	<cms:embed 'header.html' />			
		<!-- Content Here -->
	    <div class="container-fluid">
            <div class="row">
                <div class="gxcpl-ptop-30"></div>
				<!-- Section Divider -->
				<div class="gxcpl-ptop-10"></div>
				<!-- <div class="gxcpl-divider-dark"></div> -->
				<div class="gxcpl-ptop-10"></div>
				<!-- Section Divider -->

				<!-- Mid Night Position -->
				<cms:match_route debug='0' />
				<cms:embed "mid-posi-2/<cms:show k_matched_route />.html" />
				<!-- Mid Night Position -->
            </div>
	    </div>
	    <!-- Content Here -->
	<cms:embed 'footer.html' />			
<?php COUCH::invoke( K_IGNORE_CONTEXT ); ?>