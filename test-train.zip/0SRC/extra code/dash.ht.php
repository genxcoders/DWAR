<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Dashboard" order="2" />
	<cms:embed 'header.html' />
	<style type="text/css">
		.nav-tabs {
		    border-bottom: 1px solid transparent !important;
		}
	</style>
		<!-- Content Here -->
		<div class="container">
			<div class="row">
				<div class="gxcpl-ptop-30"></div>

				<cms:set current = "<cms:date format='Y-m-d' />" scope='global' />
				<cms:set yesterday = "<cms:date return='yesterday' format='Y-m-d'/>" scope='global' />
				<cms:set td_yd = "<cms:date my_today_yesterday format='Y-m-d' />" scope='global' />
				<!-- Section Title -->
				<div class="gxcpl-tab">
					<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=<cms:show my_icp /> | to_ho=<cms:show my_toho /> | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | is_interchanged='1' " show_future_entries='1' limit="1">
					<ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active">
							<a href="#today_yesterday0" aria-controls="today_yesterday0" role="tab" data-toggle="tab">TODAY<cms:show current /></a>
						</li>
						<li role="presentation">
							<a href="#today_yesterday1" aria-controls="today_yesterday1" role="tab" data-toggle="tab">YESTERDAY<cms:show yesterday /></a>
						</li>
					</ul>
					</cms:pages>
					<div class="gxcpl-ptop-20"></div>
					<div class="tab-content">
						<!-- Today -->
						<div role="tabpanel" class="tab-pane active" id="today_yesterday0">
							<!-- ET -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>ET</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set et_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=ET | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' /> 
												<cms:set et_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=ET | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:show et_to /></td>
														<td class="text-center"><cms:show et_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong><center>Individual</center></strong>
											<div class="gxcpl-ptop-10"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">
														ET
													</td>
													<td class="text-center">
														<cms:show et_to />
													</td>
													<td class="text-center">
														<cms:show et_ho />
													</td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- ET -->
							<!-- BD -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>BD</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set bd_to ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BD | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' /><cms:set cndb_to ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CNDB | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												
												<cms:set bd_ho ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BD | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<cms:set cndb_ho ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CNDB | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:add bd_to cndb_to /></td>
														<td class="text-center"><cms:add bd_ho cndb_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">BD</td>
													<td class="text-center"><cms:show bd_to /></td>
													<td class="text-center"><cms:show bd_ho /></td>
												</tr>
												<tr>
													<td class="text-center">CNDB</td>
													<td class="text-center"><cms:show cndb_to /></td>
													<td class="text-center"><cms:show cndb_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- BD -->
							<!-- SECR -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>SECR</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set ngp_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=NGP | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												<cms:set ngp_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=NGP | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<cms:set gcc_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=GCC | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												<cms:set gcc_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=GCC | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<cms:set cwa_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CWA | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												<cms:set cwa_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CWA | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<cms:set caf_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CAF | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												<cms:set caf_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CAF | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"> 
															<cms:add ngp_to "<cms:add gcc_to "<cms:add cwa_to caf_to />" />" />
														</td>
														<td class="text-center">
															<cms:add ngp_ho "<cms:add gcc_ho "<cms:add cwa_ho caf_ho />" />" />
														</td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">NGP</td>
													<td class="text-center"><cms:show ngp_to /></td>
													<td class="text-center"><cms:show ngp_ho /></td>
												</tr>
												<tr>
													<td class="text-center">GCC</td>
													<td class="text-center"><cms:show gcc_to /></td>
													<td class="text-center"><cms:show gcc_ho /></td>
												</tr>
												<tr>
													<td class="text-center">CWA</td>
													<td class="text-center"><cms:show cwa_to /></td>
													<td class="text-center"><cms:show cwa_ho /></td>
												</tr>
												<tr>
													<td class="text-center">CAF</td>
													<td class="text-center"><cms:show caf_to /></td>
													<td class="text-center"><cms:show caf_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- SECR -->
							<!--  SCR -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>SCR</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set bpq_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BPQ | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												<cms:set pmkt_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=PMKT | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
												<cms:set bpq_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BPQ | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<cms:set pmkt_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=PMKT | is_interchanged='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:add bpq_to pmkt_to /></td>
														<td class="text-center"><cms:add bpq_ho pmkt_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">BPQ</td>
													<td class="text-center"><cms:show bpq_to /></td>
													<td class="text-center"><cms:show bpq_ho /></td>
												</tr>
												<tr>
													<td class="text-center">PMKT</td>
													<td class="text-center"><cms:show pmkt_to /></td>
													<td class="text-center"><cms:show pmkt_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- SCR -->
							<!-- STABLE -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>STABLE TRAIN</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set stable_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=<cms:show my_icp /> | is_stabled='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
 												<cms:set stable_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=<cms:show my_icp /> | is_stabled='1' | arrival_date=<cms:date my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
 												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:show stable_to /></td>
														<td class="text-center"><cms:show stable_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">STABLE</td>
													<td class="text-center"><cms:show stable_to /></td>
													<td class="text-center"><cms:show stable_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- STABLE -->
						</div>
						<!-- Today -->
						<!-- Yesterday -->
						<div role="tabpanel" class="tab-pane" id="today_yesterday1">
							<!-- ET -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>ET</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set et_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=ET | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' /> 
												<cms:set et_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=ET | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:show et_to /></td>
														<td class="text-center"><cms:show et_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong><center>Individual</center></strong>
											<div class="gxcpl-ptop-10"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">
														ET
													</td>
													<td class="text-center">
														<cms:show et_to />
													</td>
													<td class="text-center">
														<cms:show et_ho />
													</td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- ET -->
							<!-- BD -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>BD</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set bd_to ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BD | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' /><cms:set cndb_to ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CNDB | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												
												<cms:set bd_ho ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BD | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<cms:set cndb_ho ="<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CNDB | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:add bd_to cndb_to /></td>
														<td class="text-center"><cms:add bd_ho cndb_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">BD</td>
													<td class="text-center"><cms:show bd_to /></td>
													<td class="text-center"><cms:show bd_ho /></td>
												</tr>
												<tr>
													<td class="text-center">CNDB</td>
													<td class="text-center"><cms:show cndb_to /></td>
													<td class="text-center"><cms:show cndb_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- BD -->
							<!-- SECR -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>SECR</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set ngp_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=NGP | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												<cms:set ngp_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=NGP | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<cms:set gcc_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=GCC | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												<cms:set gcc_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=GCC | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<cms:set cwa_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CWA | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												<cms:set cwa_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CWA | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<cms:set caf_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CAF | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												<cms:set caf_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=CAF | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"> 
															<cms:add ngp_to "<cms:add gcc_to "<cms:add cwa_to caf_to />" />" />
														</td>
														<td class="text-center">
															<cms:add ngp_ho "<cms:add gcc_ho "<cms:add cwa_ho caf_ho />" />" />
														</td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">NGP</td>
													<td class="text-center"><cms:show ngp_to /></td>
													<td class="text-center"><cms:show ngp_ho /></td>
												</tr>
												<tr>
													<td class="text-center">GCC</td>
													<td class="text-center"><cms:show gcc_to /></td>
													<td class="text-center"><cms:show gcc_ho /></td>
												</tr>
												<tr>
													<td class="text-center">CWA</td>
													<td class="text-center"><cms:show cwa_to /></td>
													<td class="text-center"><cms:show cwa_ho /></td>
												</tr>
												<tr>
													<td class="text-center">CAF</td>
													<td class="text-center"><cms:show caf_to /></td>
													<td class="text-center"><cms:show caf_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- SECR -->
							<!--  SCR -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>SCR</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set bpq_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BPQ | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												<cms:set pmkt_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=PMKT | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=0 " count_only='1' />" scope='global' />
												<cms:set bpq_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=BPQ | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<cms:set pmkt_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=PMKT | is_interchanged='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' />| to_ho=1 " count_only='1' />" scope='global' />
												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:add bpq_to pmkt_to /></td>
														<td class="text-center"><cms:add bpq_ho pmkt_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">BPQ</td>
													<td class="text-center"><cms:show bpq_to /></td>
													<td class="text-center"><cms:show bpq_ho /></td>
												</tr>
												<tr>
													<td class="text-center">PMKT</td>
													<td class="text-center"><cms:show pmkt_to /></td>
													<td class="text-center"><cms:show pmkt_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- SCR -->
							<!-- STABLE -->
							<div class="col-md-2 col-sm-6 col-xs-6">
								<a href="#" class="gxcpl-fc-21">
									<div class="gxcpl-dashboard-box gxcpl-shadow-1 gxcpl-br-2 gxcpl-bg-white">
										<h6 class="text-center">
											<div class="text-center gxcpl-dashboard-box-card">
												<strong>STABLE TRAIN</strong>
											</div>
											<div class="gxcpl-dashboard-box-card">
												<cms:set stable_to = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=<cms:show my_icp /> | is_stabled='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' /> | to_ho=0 " count_only='1' />" scope='global' />
 												<cms:set stable_ho = "<cms:pages masterpage="pointwise-interchange.php" custom_field="interchange=<cms:show my_icp /> | is_stabled='1' | arrival_date=<cms:date return='yesterday' my_today_yesterday format='Y-m-d' /> | to_ho=1 " count_only='1' />" scope='global' />
 												<table width="100%;">
													<tr>
														<th></th>
														<th class="text-center">T/O</th>
														<th class="text-center">H/O</th>
													</tr>
													<tr>
														<th class="text-center">TOTAL</th>
														<td class="text-center"><cms:show stable_to /></td>
														<td class="text-center"><cms:show stable_ho /></td>
													</tr>
												</table>
											</div>
											<div class="gxcpl-ptop-10"></div>
											<strong>Individual</strong>
											<div class="gxcpl-ptop-5"></div>
											<table width="100%">
												<tr>
													<th class="text-center">
														Intr
													</th>
													<th class="text-center">
														T/O
													</th>
													<th class="text-center">
														H/O
													</th>
												</tr>
												<tr>
													<td class="text-center">STABLE</td>
													<td class="text-center"><cms:show stable_to /></td>
													<td class="text-center"><cms:show stable_ho /></td>
												</tr>
											</table>
										</h6>	
				                    </div>
				                </a>
			                    <div class="gxcpl-ptop-20"></div>
							</div>
							<!-- STABLE -->
						</div>
						<!-- Yesterday -->
					</div>
				</div>
			</div>
		</div>
		<!-- Content Here -->
	<cms:embed 'footer.html' />
<?php COUCH::invoke( ); ?>