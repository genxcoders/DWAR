<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="DEMO" clonable="1" routable='1' parent='' order='1' executable="0" >
	<cms:editable name='csv' required='0' allowed_ext='csv' max_size='2000000' type='securefile' label='CSV' has_header='0' />
	<!-- Custom Routes -->
	<cms:route name='list_demo' path='' />
	<cms:route name='create_demo' path='create' />
    <cms:route name='edit_demo' path='{:id}/edit' >
    	<cms:route_validators id='non_zero_integer' />
	</cms:route>
	<cms:route name='delete_demo' path='{:id}/delete' >
	    <cms:route_validators id='non_zero_integer' />
	</cms:route>
<!-- Custom Routes -->
</cms:template>
<cms:embed 'header.html' />
	<!-- Content Here -->
	<div class="container">
		<div class="row">
			<div class="gxcpl-ptop-30"></div>

			<!-- Section Title -->
			<cms:embed 'crud-title.html' />
			<!-- Section Title -->

			<!-- Section Divider -->
			<div class="gxcpl-ptop-10"></div>
			<!-- <div class="gxcpl-divider-dark"></div> -->
			<div class="gxcpl-ptop-10"></div>
			<!-- Section Divider -->

			<!-- demo -->
			<cms:match_route debug='0' />
			
			<div class="col-md-3">
				<cms:embed "demo/create_demo.html" />
			</div>

			<div class="col-md-9">
				<cms:match_route debug='0' />
				<cms:embed "demo/list_demo.html" />
			</div>
			<!-- demo -->
		</div>
	</div>
	<!-- Content Here -->
<cms:embed 'footer.html' />
<?php COUCH::invoke( K_IGNORE_CONTEXT ); ?>