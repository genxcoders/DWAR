<?php require_once( 'couch/cms.php' ); ?>
<cms:template title="Transport Report" clonable='1' parent='_coal_' order="4" />
<cms:embed "header.html" />
<div class="container-fluid">
	<h4 class="gxcpl-no-margin">
	    DAILY TRANSPORTATION REPORT
	</h4>
	<!-- List View -->
	<div class="gxcpl-ptop-10"></div>
	<div class="gxcpl-divider-dark"></div>
	<div class="gxcpl-ptop-10"></div>
	<cms:embed 'searchtrnsrport.html' />

	<cms:if my_search_str eq '' >

	<cms:else />

	<!-- Transportation Table -->
	<div class="col-md-12">
			<div class="gxcpl-ptop-10"></div>
		<div class="gxcpl-card">
			<!-- Body -->
			<div class="gxcpl-card-header">
				<div class="row">
					<div class="col-md-12 col-xs-12">
						<div class="row">
							<div class="col-md-8">
								<h4 class="gxcpl-no-margin">
									TRANSPORTATION REPORT FROM <cms:date "<cms:gpc 'from_date' method='get' />" format='d/m/Y' /> TO <cms:date "<cms:gpc 'to_date' method='get' />" format='d/m/Y' />
								</h4>
							</div>
							<cms:ignore>
							<!-- <div class="col-md-4">
								<label class="text-uppercase">Search Sidings</label>
								<input type="text" class="typeahead" placeholder="Search using Sidings...">
								<div class="gxcpl-ptop-10"></div>
							</div> -->
							</cms:ignore>
						</div>
					</div>
				</div>
			</div>
			<div class="gxcpl-card-body	tableFixHead gxcpl-scroll" style="overflow-x: auto;">
				<table class="gxcpl-table userTbl" width="100%" >
					<thead>
						<tr>
							<th class="text-center" rowspan="2" style="padding: 0;">Sr. No.</th>
							<th class="text-center" rowspan="2" style="padding: 0;">Date</th>
							<th class="text-center" rowspan="2" style="padding: 0;">Siding</th>
							<th class="text-center" rowspan="2" style="padding: 0;">Tons</th>
							<th class="text-center" rowspan="2" style="padding: 0;">Action</th>
						</tr>
					</thead>
					<cms:set tontotal='0' scope='global' />
					<tbody>
						<cms:pages masterpage='transport.php' show_future_entries="1" custom_field="<cms:show my_search_str />" orderby="transdate" order="asc" >
							<cms:no_results>
								<tr>
									<cms:if k_user_access_level gt '7'>
									<td colspan="5" class="text-center">
										- No Result -
									</td>
									</cms:if>
								</tr>
							</cms:no_results>

								<tr>
									<td class="text-center" style="padding: 0;">
										<cms:show k_absolute_count />
									</td>
									<td class="text-center" style="padding: 0;">
										<cms:date transdate format="d/m/Y" />
									</td>
									<td class="text-center" style="padding: 0;">
										<cms:related_pages 'siding'>
											<cms:no_results>
												-NA-
											</cms:no_results>
											<cms:show k_page_title />
										</cms:related_pages>
									</td>
									<td class="text-center" style="padding: 0;">
										<cms:if tons >
											<cms:show tons />
										<cms:else />
											-NA-
										</cms:if>
									</td>
									<td class="text-center" style="padding: 0;" >
										<cms:popup_edit ' siding | tons | transdate' link_text="<i class='fa fa-edit'></i>" />
										<a href="<cms:add_querystring "<cms:route_link 'delete_trans' rt_id=k_page_id />" "url=transport-report.php&from_date=<cms:date "<cms:gpc 'from_date' method='get' />" format='Y-m-d' />
										&to_date=<cms:date "<cms:gpc 'to_date' method='get' />" format='Y-m-d' />
										&submit=Search
										&k_hid_search=search
										&nc=1" />">
											<i class="fa fa-trash"></i>
										</a>
									</td>	
								</tr>
								<cms:set tontotal = "<cms:add tontotal tons />" scope='global' />
						</cms:pages>
					</tbody>
				</table>
			</div>

			<div class="gxcpl-card-footer gxcpl-no-padding">
				<div class="row">
					<div class="col-md-3 col-md-offset-7 col-xs-7 col-xs-offset-4 text-center">
						<strong>Total Tons:</strong>
						<cms:show tontotal />
					</div>
				</div>
			</div>
		</div>
		<div class="gxcpl-ptop-50"></div>
	</div>
	<!-- Transportation Table -->
	</cms:if>
</div>
<div class="gxcpl-ptop-50"></div>
<cms:embed "footer.html" />
<?php COUCH::invoke( ); ?>