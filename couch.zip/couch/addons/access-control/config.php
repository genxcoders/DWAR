<?php

    if ( !defined('K_COUCH_DIR') ) die(); // cannot be loaded directly

    // Extended users template file.
    $EXTENDED_USERS_TEMPLATE = 'users/index.php';